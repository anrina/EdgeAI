# CiRa-Core
CiRA CORE: Deep Learning Platform
CiRA CORE คือหนึ่งนวัตกรรม AI ที่ถูกนำมาใช้จริงในอุตสหกรรมโดย CiRA CORE คือ platform กลางที่ออกแบบให้ทำหน้าที่เชื่อมโยงเทคโนโลยีด้าน AI ในส่วนของ Deep learning หรือการเรียนรู้เชิงลึก เป็นเทคโนโลยีที่เลียนแบบเครือข่ายเซลล์ประสาทในสมองมนุษย์ ทำให้เกิดการเรียนรู้จดจำข้อมูลหรือภาพต่างๆ รวมทั้งสามารถวิเคราะห์แยกแยะ คาดการณ์และตัดสินใจได้อย่างแม่นยำ เพื่อนำมาประยุกต์ใช้งานได้หลากหลาย โดยเฉพาะในด้านอุตสาหกรรม
CiRA CORE คือ Platform ที่เป็น Core technology ซึ่งเทียบกับระบบการแอนดรอยด์ที่อยู่ในสมาร์ทโฟน นาฬิกา กล้องดิจิทัล รวมถึงสมาร์ททีวี โดยเราสามารถสร้างอัลกอริทึมแอปพลิเคชั่นต่างๆ เช่น Deep Learning ใส่เข้าไป เพื่อสร้างการเรียนรู้และจดจำให้แก่ระบบ เช่น การสั่งให้จดจำว่ามีสิ่งของหน้าตาเป็นแบบนี้ หลังจากเรียนรู้และจดจำแล้ว ก็นำไปใช้ในทางอุตสาหกรรมก็ต้องมีการสั่งงาน ดังนั้น CiRA CORE คือ Platform กลางที่เชื่อมโยงปแอปพลิเคชั่นต่างๆ ไปสู่การใช้งานจริง หรือกล่าวได้ว่าคือตัวกลางระหว่างการเรียนรู้จดจำ

----------
## for ubuntu 18.04

**step #1**

    sudo apt-get update

**step #2**

    sudo apt-get install expect -y

**step #3**
ดาวน์โหลด CiRA-CORE master version และแตกไฟล์ zip
https://git.cira-lab.com/cira/cira-core/-/archive/master/cira-core-master.zip

**step #4**
แตกไฟล์ zip และเก็บไว้ที่ directory → Home

**step #5**
ไปที่หน้า terminal

    cd cira-core-master/

**step #6**

    python install.py [ubuntu_password]

*** ใส่รหัสผ่าน ตัวอย่างเช่น python install.py 123456

----------
## for Windows 10 Beta

**step #1**
เข้าลิ้งและดาวน์โหลดโปรแกรม [https://tinyurl.com/cira-core-win](https://tinyurl.com/cira-core-win)

**step #2**
ติดตั้ง ROS Melodic : 1-ros-setup.exe

**step #3**
ติดตั้งโปรแกรม CiRA CORE : 2-cira-core-setup.exe

หมายเหตุ : อาจต้องปิดโปรแกรมกำจัดไวรัสในการรันและติดตั้ง


----------
# Get Started CiRA-core

CiRA-Core เป็นโปรแกรมที่ทำงานอยู่บนระบบปฏิบัติการหุ่นยนต์ หรือ ROS โดย ROS เป็น Framework ที่เป็นที่นิยมสำหรับการพัฒนาหุ่นยนต์ โดยแนวคิดของ ROS คือการแตกโปรแกรมให้เป็น Node ย่อยๆ ซึ่งแต่ละ Node จะมีหน้าที่ของตัวเองเช่น Node1 ทำหน้าที่รับภาพประมวลผลและสั่งงานหุ่นยนต์



การทำงานของ CIRA-Core 
CIRA-Core **จะดึงข้อมูลจาก sensor มาประมวณผล และจะเป็นตัวกลางในการรับส่งข้อมูลมาจาก senser เพื่อไปควบคุม actuators**

![sensor](https://paper-attachments.dropbox.com/s_6290B2E03A0FC7807052212F98444197290FFECE0171CAD24C4715287F2F8265_1614920339066_file.jpeg)

![brain](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1SK-AOGP9Cbk-zLBnsgvuIH6Xj-dbUUC4GQ&usqp=CAU)

![actuators](https://paper-attachments.dropbox.com/s_6290B2E03A0FC7807052212F98444197290FFECE0171CAD24C4715287F2F8265_1614920572522_file.jpeg)














CIRA-Core เป็นโปโตคอลที่เชื่อมกับโปโตคอลอื่นๆ โดยการจะเชื่อมกับอุปกรณ์หรือ network
มันต้องมีตัวกลางตัวหนึ่งที่เชื่อมโยงไปได้ เรียกว่า middleware
CIRA-Core คือ middleware ที่เชื่อมโยงระหว่าง hardware ในอุตสาหกรรม กับ ai

เครื่องมือที่ใช้เป็นพื้นฐานใน Platform CiRA CORE มีดังต่อไปนี้



| **No.** | **ชื่อกล่อง**   | **ภาพ**                                                                                                                               | **หน้าที่**                                   |
| ------- | --------------- | ------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------- |
| 1       | ButtonRun       | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655647879_image.png) | ใช้กดปุ่มเมื่อต้องการเริ่มการใช้งานโปรแกรม    |
| 2       | ImageSubscribe  | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655656517_image.png) | ดึงข้อมูลภาพจากเว็บแคม                        |
| 3       | ImportVideoFile | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655665263_image.png) | นำข้อมูลไฟล์วีดีโอเข้ามาใช้งาน                |
| 4       | ImportImageFile | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655672954_image.png) | นำข้อมูลไฟล์ภาพนิ่งเข้ามาใช้งาน               |
| 5       | ImageSlide      | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655682449_image.png) | นำข้อมูลภาพนิ่งหลายๆไฟล์เข้ามาใช้งาน แบบสไลซ์ |
| 6       | Debug           | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655697030_image.png) | แสดงผลข้อมูลที่รับมา                          |
| 7       | Label           | ![](https://paper-attachments.dropbox.com/s_B4A1535CF18D09AC5600478AC6523D1D390E164ADBC7B3BB52C9B6B90C506F45_1614655703775_image.png) | ป้ายชื่อ(แสดงผลของข้อความ)                    |





CiRA CORE เป็น Platform ที่ช่วยควบคุมคุณภาพในกระบวนการผลิต

