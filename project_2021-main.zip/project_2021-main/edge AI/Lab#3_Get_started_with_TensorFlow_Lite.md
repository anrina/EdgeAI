# Lab#3_Get_started_with_TensorFlow_Lite

สวัสดีค่ะ เนื้อหาในส่วนนี้จะเป็นเรื่องของการลองใช้และทำ Tiny ML เองภายในgoogle colab เครื่องมือที่น่าสนใจนี้ สนับสนุน Tensorflow เพราะว่า Tensorflow ก็Googleพัฒนานี่แหละค่ะ สำหรับคนที่เสป็คเครื่องไม่แรงก็สามารถมาเทรนโดยใช้Colabได้ค่ะ หากไม่ได้ใช้แบบPro ก็ต้องลุ้นเอาว่าจะสุ่มได้CPUอะไรค่ะในแต่ละครั้งที่Run

คำเตือน ถ้าจะTrain model อย่าลืมเปิดเป็นการRun แบบGPUนะคะ ไม่งั้นนานแน่ค่ะ

วิธีการศึกษาTiny ML

Labสุดท้าย ทำTransfer learning ง่ายๆ บน Yolo2/mobilenet-1, Sipeed Max


ขอแนะนำการมองภาพรวมที่ง่ายมากๆก่อนเลยค่ะ ของTiny ML โดยอันนี้เป็นของTensorflowเองค่ะ
Beginner:

https://colab.research.google.com/github/tensorflow/docs/blob/master/site/en/tutorials/quickstart/beginner.ipynb


สำหรับผู้ที่มีประสบการณ์ด้านนี้มาบ้างแล้วขอเสนอที่ยากขึ้นมาอีกค่ะ

https://colab.research.google.com/github/tensorflow/docs/blob/master/site/en/tutorials/quickstart/advanced.ipynb


จากนี้ไปเราจะเริ่ม Lab ของเรา!

https://colab.research.google.com/github/don/tinyml-workshop/blob/master/arduino_tinyml_workshop.ipynb


แต่เดี๋ยวก่อนค่ะเราจะมาค่อยๆเคลียร์โจทย์ของเราทีละสเต็ปเพื่อความเข้าใจในMachine learnning นะคะ
โดยเราอ้างอิงมาจาก https://github.com/don/tinyml-workshop
เพื่อประโยชน์ทางการศึกษาเท่านั้นค่ะ

# **Exercise 1: Development Environment**
## **Arduino IDE**

ติดตั้ง Arduino IDE จาก [https://arduino.cc/downloads](https://arduino.cc/downloads)

![Arduino IDE Download](https://github.com/don/tinyml-workshop/raw/master/exercises/images/ArduinoIDE.png)


**Arduino nRF528x Boards Definitions**
ใช้ Arduino Boards Manager เพื่อติดตั้ง “Arduino nRF528x Boards (Mbed OS)”. เปิด Boards Manager ใช้เมนู *Tools -> Board: -> Boards Manager...*

![Arduino Boards Manager](https://github.com/don/tinyml-workshop/raw/master/exercises/images/BoardManager-Menu.png)


ค้นหา "Nano 33 BLE" และติดตั้ง Arduino nRF528x Boards (Mbed OS)

![Arduino nRF528x Board Definitions](https://github.com/don/tinyml-workshop/raw/master/exercises/images/BoardsManager.png)


**Arduino Libraries**
ติดตั้ง Arduino libraries อื่นๆโดยใช้ Library manager:

- TensorFlow Lite library (ค้นหาจาก "Arduino_TensorFlowLite")
- Arduino LSM9DS1 library (ค้นหาจาก "Arduino_LSM9DS1")

เปิด library manager ใช้เมนู *Tools -> Manage Libraries...*

![Arduino Library Manager Menu](https://github.com/don/tinyml-workshop/raw/master/exercises/images/ManageLibraries.png)


ค้นหา "Arduino_TensorFlowLite". คลิกปุ่ม **Install เพื่อติดตั้ง** TensorFlow Lite for Microcontrollers

![Arduino TensorFlow Lite library](https://github.com/don/tinyml-workshop/raw/master/exercises/images/library-tensorflowlite.png)


ค้นหา "Arduino_LSM9DS1".  คลิกเพื่อติดตั้ง Arduino LSM9DS1 accelerometer, magnetometer, and gyroscope library.

![Arduino LSM9DS1 library](https://github.com/don/tinyml-workshop/raw/master/exercises/images/library-arduinolsm9ds1.png)

# **Exercise 2: Hardware**
![Picture of Arduino Nano 33 BLE board](https://github.com/don/tinyml-workshop/raw/master/exercises/images/nano-33-ble.jpg)

## เริ่มต้นใช้งานตั้งแต่แกะกล่องและตั้งค่า
    1. นำบอร์ด Arduino Nano 33 BLE ออกจากกล่อง
    2. เสียบสายไมโคร USB เข้ากับบอร์ดและคอมพิวเตอร์ของคุณ
    3. เปิดแอปพลิเคชัน Arduino IDE บนคอมพิวเตอร์ของคุณ
    4. เลือกบอร์ด 'Tools -> Board -> Arduino Nano 33 BLE`
    5. เลือกพอร์ต `` Tools -> Port -> COM5 (Arduino Nano 33 BLE) 'โปรดทราบว่าพอร์ตจริงอาจแตกต่างกันในคอมพิวเตอร์ของคุณ
## **Hardware Test**
    1. เสียบสายไมโคร USB เข้ากับบอร์ดและคอมพิวเตอร์ของคุณ
    2. เปิด `ArduinoSketches / Hardware_Test / Hardware_Test.ino` ใน Arduino IDE
    3. เลือกบอร์ด 'Tools -> Board -> Arduino Nano 33 BLE`
    4. เลือกพอร์ต `` Tools -> Port -> COM5 (Arduino Nano 33 BLE) 'โปรดทราบว่าพอร์ตจริงอาจแตกต่างกันในคอมพิวเตอร์ของคุณ
    5. อัปโหลดโค้ดไปที่บอร์ด "Sketch -> Upload"
    6. ไฟ LED ทั้งสองข้างพอร์ต USB ควรติดสว่าง
    7. เปิดซีเรียลมอนิเตอร์ "เครื่องมือ -> ซีเรียลมอนิเตอร์" เพื่อดูข้อความดีบัก
    8. หากทุกอย่างทำงานอย่างถูกต้องไฟ LED จะเริ่มกะพริบอย่างรวดเร็ว
1. หมายเหตุ: ในครั้งแรกที่คุณอัปโหลดภาพร่างไปยัง Arduino Nano 33 BLE ชื่อพอร์ต USB อาจเปลี่ยนไป ในกรณีนี้คุณต้องเลือกพอร์ตอีกครั้งโดยใช้เมนู "เครื่องมือ -> พอร์ต"


# **Exercise 3: Visualize the IMU Data**

ขั้นตอนต่อไปคือการใช้โปรแกรม Arduino เพื่อจับข้อมูลการเคลื่อนไหวจาก IMU

1. เปิด tinyml-workshop / ArduinoSketches / IMU_Capture / IMU_Capture.ino ใน Arduino IDE
2. รวบรวมร่างและอัปโหลดไปยังบอร์ด: "ร่าง -> อัปโหลด"
3. เปิด Serial Monitor: "Tools -> Serial Monitor"
4. เขย่ากระดาน การเปลี่ยนแปลงความเร่งจะเริ่มบันทึกข้อมูลจาก IMU ใน Serial Monitor
5. ปิดหน้าต่าง Serial Monitor
6. เปิด Serial Plotter: "Tools -> Serial Plotter"
7. เขย่ากระดาน การเปลี่ยนแปลงของความเร่งจะเริ่มสร้างกราฟข้อมูลใน Serial Plotter
8. จับท่าทางต่างๆซ้ำ ๆ เพื่อให้เข้าใจว่าข้อมูลการฝึกจะเป็นอย่างไร
9. ปิด Serial Plotter
![screenshot of serial monitor with IMU data](https://github.com/don/tinyml-workshop/raw/master/exercises/images/serial-monitor-imu.png)

![screenshot of serial plotter with IMU data](https://github.com/don/tinyml-workshop/raw/master/exercises/images/serial-plotter-imu.png)

# **Exercise 4: Gather the Training Data**
    1. กดปุ่มรีเซ็ตบนบอร์ด
    2. เปิด Serial Monitor: "Tools -> Serial Monitor"
    3. ทำท่าชกต่อยกับบอร์ดในมือคุณจะเห็นบันทึกข้อมูลเซ็นเซอร์ใน Serial Monitor
    4. ทำท่าทางซ้ำ 10 ครั้ง (หรือมากกว่า) เพื่อรวบรวมข้อมูลเพิ่มเติม
    5. คัดลอกและวางข้อมูลจากเอาต์พุตอนุกรมไปยังไฟล์ข้อความใหม่ชื่อ "punch.csv"
    6. ปิด Serial Monitor
    7. กดปุ่มรีเซ็ตบนบอร์ด
    8. เปิด Serial Monitor: "Tools -> Serial Monitor"
    9. ทำท่าดิ้นโดยมีกระดานอยู่ในมือ
    10. ทำซ้ำท่าทางดิ้นอย่างน้อย 10 ครั้ง
    11. คัดลอกและวางเอาต์พุตอนุกรมลงในไฟล์ข้อความใหม่ชื่อ "flex.csv"
![screenshot of serial monitor with IMU data](https://github.com/don/tinyml-workshop/raw/master/exercises/images/serial-monitor-imu.png)

## **Creating CSV Files**

Visual Studio Code, Sublime Text หรือ Atom ทั้งหมดจะใช้งานได้ดีสำหรับการสร้างไฟล์ CSV หากคุณไม่ได้ติดตั้งโปรแกรมแก้ไขเหล่านี้ให้ลองใช้ Notepad.exe บน Windows หรือ TextEdit บน MacOS โปรดทราบว่า TextEdit ต้องการบันทึกข้อมูลในรูปแบบ Rich Text เป็นค่าเริ่มต้น อย่าลืมเลือกรูปแบบ -> สร้างข้อความธรรมดาก่อนเลือกไฟล์ -> บันทึก

# **Exercise 5: Machine Learning**

เราจะใช้ Google Colab เพื่อฝึกโมเดลแมชชีนเลิร์นนิงของเรา Colab มีสมุดบันทึก Jupyter ที่ช่วยให้เราสามารถรันโมเดลการเรียนรู้ของเครื่องในเว็บเบราว์เซอร์

![Screenshot of Google Colab website](https://github.com/don/tinyml-workshop/raw/master/exercises/images/colab.png)

## **3rd Party Cookies**

กรณีที่พบปัญหา error about 3rd party cookies.
สามารถ enable 3rd party cookiesได้โดยการ เพิ่ม exception สำหรับ `[*.]googleusercontent.com`.

![Screenshot adding 3rd party cookie exception for googleusercontent.com](https://github.com/don/tinyml-workshop/raw/master/exercises/images/colab-3rd-party-cookie-exception.png)

## **Open the Notebook**

เปิด [arduino_tinyml_workshop.ipynb](https://github.com/don/tinyml-workshop/blob/master/arduino_tinyml_workshop.ipynb) notebookใน Google Colab และปฏิบัติตามคำแนะนำในนั้นเพื่อเตรียมข้อมูลและฝึกโมเดล

https://colab.research.google.com/github/don/tinyml-workshop/blob/master/arduino_tinyml_workshop.ipynb

# **Exercise 7: Classifying IMU Data**
    1. เปิด tinyml-workshop / ArduinoSketches / IMU_Classifier / IMU_Classifier.ino ใน Arduino IDE
    2. เปลี่ยนไปที่แท็บ model.h
    3. แทนที่เนื้อหาของ model.h ด้วยเวอร์ชันที่คุณดาวน์โหลดจาก Colab
    4. อัปโหลดร่าง: "ร่าง -> อัปโหลด"
    5. เปิด Serial Monitor: "Tools -> Serial Monitor"
    6. ทำท่าชกหรือดิ้น
    7. ความมั่นใจของแต่ละท่าทางจะถูกพิมพ์ไปยัง Serial Monitor (0 -> ความมั่นใจต่ำ, 1 -> ความมั่นใจสูง)
![screenshot with output of the imu classifier sketch](https://github.com/don/tinyml-workshop/raw/master/exercises/images/arduino-classifier.png)

# **Exercise 8: Emojis**
## **Print an emoji**

ตอนนี้รหัสสามารถจดจำท่าทางได้แล้วเรามาลองพิมพ์อิโมจิเพิ่มเติมจากข้อความ
เปิด tinyml-workshop / ArduinoSketches / IMU_Classifier / IMU_Classifier.ino ใน Arduino IDE หากยังไม่ได้โหลด
สร้างอาร์เรย์ char * ใหม่ชื่อ "EMOJIS" ภายในอาร์เรย์กำหนดอิโมจิเป็นสตริงยูนิโคดที่เข้ารหัส UTF-8 อาร์เรย์นี้ต้องมีความยาวเท่ากันที่อาร์เรย์ "GESTURE" ลำดับของอิโมจิในอาร์เรย์ต้องตรงกับลำดับของท่าทางสัมผัส

    const char* EMOJIS[] = {
        u8"\U0001f44a",   // punch
        u8"\U0001f4aa"    // flex 
    };

หากคุณบันทึกท่าทางสัมผัสเพิ่มเติมคุณสามารถค้นหาอักขระ Unicode ได้ในเว็บไซต์ Unicode Consortium
ในฟังก์ชัน "loop" หลังจากพิมพ์ท่าทางและความน่าจะเป็นแล้วให้เพิ่มโค้ดเพื่อพิมพ์อิโมจิสำหรับท่าทางสัมผัสหากความน่าจะเป็นมากกว่า 80%

    for (int i = 0; i < NUM_GESTURES; i++) {
        if (tflOutputTensor->data.f[i] > 0.8) {
            Serial.println(EMOJIS[i]);
            Serial.println();
        }
    }

คอมไพล์และปรับใช้โค้ดที่อัปเดตลงใน Arduino ของคุณโดยใช้ "Sketch -> อัปโหลด"
Serial Monitor ใน Arduino IDE ไม่สามารถแสดงอักขระ Unicode ได้ดังนั้นเราจึงต้องใช้เครื่องมืออื่นเพื่อดูผลลัพธ์ สำหรับผู้ใช้ Linux และ MacOS เราขอแนะนำให้ใช้เทอร์มินัล สำหรับ Windows คุณจะต้องใช้ Google Chrome

**MacOS**
เปิด Terminal ใหม่โดยกดปุ่มคำสั่ง⌘และ Space bar พิมพ์ Terminal.app ในหน้าต่างค้นหา Spotlight ที่ appers และกด Enter เมื่อเทอร์มินัลเปิดขึ้นให้พิมพ์ cat /dev/cu.usb แล้วกดปุ่ม TAB MacOS ควรเติมชื่อพอร์ตที่ Arduino เชื่อมต่ออยู่โดยอัตโนมัติ หน้าตาจะเป็นแบบ /dev/cu.usbmodem146101 ชื่อพอร์ตจริงอาจแตกต่างกันในคอมพิวเตอร์ของคุณ หากจำเป็นให้รับชื่อพอร์ตจาก Arduino IDE

![screenshot of macos with emojis](https://github.com/don/tinyml-workshop/raw/master/exercises/images/imu_classifier_emoji_mac.png)


**Linux**
เปิดเทอร์มินัลและ cat เอาท์พุทจากอุปกรณ์ Arduino หากจำเป็นให้รับชื่อพอร์ตจาก Arduino IDE

![screenshot of linux with emojis](https://github.com/don/tinyml-workshop/raw/master/exercises/images/imu_classifier_emoji_linux.png)


**Windows**
เทอร์มินัล Windows จะไม่แสดงอิโมจิ แต่เราได้สร้างหน้าเว็บที่ใช้ Web Serial API แบบทดลองใน [Google Chrome](https://google.com/chrome).
เปิดโดยใช้ Google Chrome [https://serial-monitor.glitch.me](https://serial-monitor.glitch.me/).

![Screenshot warning Chrome features need to be enabled](https://github.com/don/tinyml-workshop/raw/master/exercises/images/web-serial-disabled.png)


คุณอาจต้องเปิดใช้งาน Web Serial API โดยการสลับ #enable-experimental-web-platform-features flag ใน chrome://flags.

![Screenshot of Chrome enable-experimental-web-platform-features flag](https://github.com/don/tinyml-workshop/raw/master/exercises/images/web-serial-flag-enabled.png)


หลังจากเปิดใช้งานคุณลักษณะทดลองแล้วให้คลิกปุ่มเปิดใหม่เพื่อรีสตาร์ท Chrome เปิด [https://serial-monitor.glitch.me](https://serial-monitor.glitch.me/) แล้วคลิกปุ่มเชื่อมต่อ เลือกพอร์ต COM สำหรับ Arduino ของคุณ

![Screenshot of web ui with port selection dialog](https://github.com/don/tinyml-workshop/raw/master/exercises/images/web-serial-choose-port.png)


ทำท่าทางและผลลัพธ์จะปรากฏในหน้าเว็บ

![Screenshot of Chrome web page with text and emoji output from Arduino](https://github.com/don/tinyml-workshop/raw/master/exercises/images/web-serial-monitor.png)


ขอบคุณข้อมูลจาก  https://github.com/don/tinyml-workshop
ใช้เพื่อประโยชน์ทางการศึกษาเท่านั้นค่ะ สำหรับข้อมูลแบบเต็มสามารถเข้าไปดูใน link แหล่งอ้างอิงนี้ได้เลยค่ะ


# **Exercise 9: Applied** 

โจทย์ในขั้นนี้ต้องการให้ทำการตรวจจับท่าทางพฤติกรรมอื่นๆด้วยไม่ว่าจะเป็นการงอตัวหรือท่าทางอื่นๆ แล้วแสดงผลขึ้นจอ โดยจะขอยกตัวอย่างท่าทางงอหลัง ก้มโค้ง โดยโจทย์นี้มีจุดประสงค์หลักคือวัดความเข้าใจในการสร้างTinyML เพื่อจุดประสงค์ตามที่ต้องการเพื่อนำไปสู่การสร้างโปรเจ็คในอนาคต

โดยตัวอย่างที่ทำการกล่าวถึงในครั้งนี้เป็นส่วนหนึ่งของ โครงการสายรัดปรับสรีระอัจฉริยะ อันเป็นของผู้เขียนเอง ซึ่งมีตัวโปรแกรมไม่ตรงกับที่ปรากฎนี้แต่ก็ถือเป็นโปรเจ็คประเภท คล้ายคลึงกันจึงขอยกมาแสดงเบื้องต้น

ส่วนที่ต้องการเน้นย้ำอีกครั้งคือความสำคัญของคุณภาพข้อมูล


![](https://paper-attachments.dropbox.com/s_C977D1B51942F143D61C08FB4F1A7010B78466C51421A148B521DAFF0CBC5B16_1616970846130_Screen+Shot+2564-03-29+at+05.33.51.png)


รูปแบบข้อมูลดิบที่ผู้เขียนใช้ ได้จาก sensor Gyro จากการทำท่าทางต่างๆ โดยผู้เขียนจดไว้ว่าแต่ละช่วงเวลาทำท่าทางอะไร นำcode python มาจัดการแยกข้อมูล ซึ่งสามารถเขียนได้เองตามแต่แนวคิดของแต่ละคนว่าจะจัดการข้อมูลยังไง

![](https://paper-attachments.dropbox.com/s_C977D1B51942F143D61C08FB4F1A7010B78466C51421A148B521DAFF0CBC5B16_1616971022799_Screen+Shot+2564-03-29+at+05.36.14.png)


นำมาคัดเลือกแยกประเภทสถานะ ได้ข้อมูลที่ใช้Trainออกมาในที่สุด
จากนั้นนำเข้า Google colab ผ่าน Model ที่เตรียมไว้ ขอแนะนำว่าเลือกประเภทModel ให้สอดคล้องข้อมูลหน่อย แต่ในที่นี้เราจะใช้จากColab ที่เขาให้มาดังนั้น ในLab นี้เราจะเริ่มจากการทดสอบความเข้าใจต่อพื้นฐานสำคัญของ ML ก่อนเลย นั่นก็คือ”การเก็บข้อมูลและการจัดการข้อมูล” ให้มีคุณภาพ

คำใบ้:ถ้าข้อมูลที่ใช้ไม่ถูกแต่แรก AIของคุณก็จะผิดตั้งแต่แรกเลย, สามารถใช้ python เขียนโปรแกรมเพื่อจัดการข้อมูลให้มีคุณภาพได้, ข้อมูลหลากหลายเป็นเรื่องที่ดี แต่ข้อมูลที่เยอะเกินไปไม่ใช่เรื่องที่ดี ต้องหาจุดสมดุลด้วย , พยายามระวังการBias ของAI ให้ดี

พิจารณา

    model = tf.keras.Sequential()
    model.add(tf.keras.layers.Dense(50, activation='relu')) # relu is used for performance
    model.add(tf.keras.layers.Dense(15, activation='relu'))
    # the final layer is softmax because we only expect one gesture to occur per input
    model.add(tf.keras.layers.Dense(NUM_GESTURES, activation='softmax'))
    model.compile(optimizer='rmsprop', loss='mse', metrics=['mae'])

ที่เป็น code model ของคุณให้ดี

ขอให้โชคดีใน lab สุดท้ายค่ะ














แหล่งอ้างอิง

# **TinyML Application Development for Everyone**
![AIoT Devfest Logo](https://github.com/don/tinyml-workshop/raw/master/exercises/images/AI-IOT-devfest-AZ-2020-horiz.png)


 

## **Hands-on workshop at AIoT Devfest January 2020**

