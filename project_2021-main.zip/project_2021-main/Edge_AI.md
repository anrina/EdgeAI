# Edge AI ****
**playground ของ Edge AI** ****
concept : AI on Embedded System 

    1. ARM board ที่รองรับ Tensor Flow Lite (TinyML) → Adafruit, OpenmvM7, STM32, Sipeed, Maix, Jetson, Google Coral, Raspberry Pi, ESP-eye
    2. เรียนรู้คอร์สทั้ง 3 ตัวของ TinyML
        - [https://www.edx.org/learn/tinyml](https://www.edx.org/learn/tinyml?fbclid=IwAR3nSCHOFi6WQ8pqACluWyN3LjG74OKFzM7T9_c2q84Oyb1QpjM8j6Dv_rE)
    3. สรุปออกมาเป็น Labsheet x 5 Labsheet ลงใน AIC-BUU github

บอร์ดที่รองรับ tensor flow lite อันเป็น library Machine learning ที่เป็นที่นิยมนั้น ได้แก่บอร์ด Adafruit, OpenmvM7, STM32, Sipeed, Maix, Jetson, Google Coral, Raspberry Pi, ESP-eye

โดยขอเริ่มจาก
1.Google Coral Edge TPU เร่งการประมวลผล AI มีขายเป็นทั้งบอร์ดและ USB ราคา 74.99 – 149.99 เหรียญ

![](https://paper-attachments.dropbox.com/s_C8555CC4A60F705EBDC4571CD692657191CAE64C30C62EF0E58D6F298FBCB38D_1614923582384_image.png)


นับว่าน่าสนใจไม่น้อยเมื่อ Google ได้ออกมาประกาศเปิดตัว Google Coral Edge TPU อุปกรณ์เร่งการประมวลผล AI ที่มาทั้งในรูปแบบของ Dev Board ติดตั้ง Linux ที่มี Edge TPU อยู่ภายใน และ USB Accelerator สำหรับเชื่อมต่อกับ Raspberry Pi หรือ Linux ได้ผ่าน USB
ตัว Google Coral Dev Board นี้จะมีราคาที่ 149.99 เหรียญหรือราวๆ 4,800 บาทเท่านั้น โดยตัวอุปกรณ์จะรองรับ TensorFlow Lite และสามารถถอดใส่ระบบ System-on-Module (SOM) ได้ตามต้องการ และติดตั้งมาพร้อมกับระบบปฏิบัติการ Mendel ที่เป็น Linux ซึ่งต่อยอดมาจาก Debian Linux โดยมีสเป็คเต็มๆ ให้ตรวจสอบได้ที่ [https://coral.withgoogle.com/products/dev-board/](https://coral.withgoogle.com/products/dev-board/)
ส่วน USB Accelerator นั้นจะมีราคาเพียง 74.99 เหรียญหรือราวๆ 2,400 บาท โดยสามารถเชื่อมต่อใช้งานร่วมกับ Raspberry Pi หรือระบบ Linux เพื่อเร่งการประมวลผล AI โดยเฉพาะได้ ผู้ที่สนใจสามารถตรวจสอบรายละเอียดได้ที่ [https://coral.withgoogle.com/products/accelerator/](https://coral.withgoogle.com/products/accelerator/)
อ้างอิง https://www.techtalkthai.com/google-coral-edge-tpu-is-announced/

 2.Adafruit
 จะขอยกตัวอย่างจากproject track gyro
 Serial out gesture demo compile & upload
Let's start with the plain Arduino TensorFlow demo. **Don't forget you have to perform all the steps in the previous page for installing Arduino IDE, Adafruit SAMD support, libraries, and board/port selection!**
We adapted the default gesture demo to use the LIS3DH, so you *cannot* use the example in the Arduino TensorFlowLite library Instead, use the one in `Adafruit TensorFlow Lite` called `magic_wand`

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/202/medium800/adafruit_products_image.png?1573772891)


Compile & upload this example!

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/203/medium800/adafruit_products_image.png?1573772991)


Upon success, you may see the LED on the board pulsing. The best way to see the output is to select the **Serial Monitor**

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/206/medium800/adafruit_products_image.png?1573773154)


You'll see steaming data coming out on the Serial Monitor. This is the 3 axis accelerometer data. We output it so that you can have some more debugging data which can be really handy when training/debugging gestures. You can also plot it with the Serial Plotter if you like (close the Monitor first)
Move and twist the badge to see the red/green/blue lines change.

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/207/medium800/adafruit_products_image.png?1573773250)


Close the Plotter and re-open the monitor to see the streaming data again. This time, with the **screen facing you, and the USB port pointing to the ceiling** perform one of three gestures:

## Wing

This gesture is a **W** starting at your top left, going down, up, down up to your top right
When that gesture is detected you'lll see the front NeoPixels turn yellow, and the following print out on the Serial Monitor:

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/208/medium800/adafruit_products_image.png?1573773544)

## Ring

This gesture is a **O** starting at top center, then moving clockwise in a circle to the right, then down, then left and back to when you started in the top center
When that gesture is detected you'll see the front NeoPixels turn purple, and the following print out on the Serial Monitor:

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/209/medium800/adafruit_products_image.png?1573774447)

## Slope

This gesture is an ***L*** starting at your top right, moving diagonally to your bottom left, then straight across to bottom right.
When that gesture is detected you'll see the front NeoPixels turn light blue, and the following print out on the Serial Monitor:

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/212/medium800/adafruit_products_image.png?1573774596)

# Arcada display output gesture demo compile & upload

Arcada is our library for handling displays and input - we have so many different boards and displays, we need a unifying library that would handle displays, filesystems, buttons, etc. For many boards, you don't need to do anything special to figure out the pinouts or part numbers!
Load up the **Adafruit_TFLite->magic_wand_arcada example**

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/213/medium800/adafruit_products_image.png?1573774679)


Make sure you have TinyUSB selected as the USB stack!

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/216/medium800/adafruit_products_image.png?1573774842)


You can upload this sketch to your board. After upload it will show up on your computer as a disk drive called CIRCUITPY (unless you changed it)

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/218/medium800/adafruit_products_image.png?1573775268)


Click this button to download the gesture images and audio clips
[Badge Gesture Images](https://learn.adafruit.com/pages/17904/elements/3046761/download?type=zip)
Navigate through the zip file to `examples\magic_wand_arcada\badge_files` then drag the files directly onto the **CIRCUITPY** drive like so:

![adafruit_products_image.png](https://cdn-learn.adafruit.com/assets/assets/000/084/241/medium800/adafruit_products_image.png?1573782313)


Click **reset** on the Badge to restart, and you should get the graphics displaying so that you can run the demo untethered!
Setup and configuration of the accelerometer and screen is done in the **accelerometer_handler**
 Download: [Project Zip](https://learn.adafruit.com/pages/17904/elements/3046772/download?type=zip) or [arduino_accelerometer_handler.cpp](https://learn.adafruit.com/pages/17904/elements/3046772/download) |  [View on Github](https://github.com/adafruit/Adafruit_TFLite/blob/master/examples/magic_wand_arcada/arduino_accelerometer_handler.cpp)
[Copy Code](https://learn.adafruit.com/tensorflow-lite-for-edgebadge-kit-quickstart/gesture-demo#)

        1. /* Copyright 2019 The TensorFlow Authors. All Rights Reserved.
        2.  
        3. Licensed under the Apache License, Version 2.0 (the "License");
        4. you may not use this file except in compliance with the License.
        5. You may obtain a copy of the License at
        6.  
        7.     http://www.apache.org/licenses/LICENSE-2.0
        8.  
        9. Unless required by applicable law or agreed to in writing, software
        10. distributed under the License is distributed on an "AS IS" BASIS,
        11. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        12. See the License for the specific language governing permissions and
        13. limitations under the License.
        14. ==============================================================================*/
        15.  
        16. #include "accelerometer_handler.h"
        17.  
        18. #include <Arduino.h>
        19. #include "Adafruit_Arcada.h"
        20. extern Adafruit_Arcada arcada;
        21.  
        22. /* this is a little annoying to figure out, as a tip - when
        23.  * holding the board straight, output should be (0, 0, 1)
        24.  * tiling the board 90* left, output should be (0, 1, 0)
        25.  * tilting the board 90* forward, output should be (1, 0, 0);
        26.  */
        27.  
        28. #if defined(ADAFRUIT_PYBADGE_M4_EXPRESS)
        29. // holding up with screen/neopixels facing you
        30. const int X_POSITION = 1;
        31. const int Y_POSITION = 2;
        32. const int Z_POSITION = 0;
        33. const bool INVERT_X = true;
        34. const bool INVERT_Y = true;
        35. const bool INVERT_Z = false;
        36. #endif
        37.  
        38. #if defined(ARDUINO_NRF52840_CIRCUITPLAY)
        39. // holding up with gizmo facing you
        40. const int X_POSITION = 1;
        41. const int Y_POSITION = 2;
        42. const int Z_POSITION = 0;
        43. const bool INVERT_X = true;
        44. const bool INVERT_Y = true;
        45. const bool INVERT_Z = false;
        46. #endif
        47.  
        48. #if defined(ARDUINO_NRF52840_CLUE)
        49. // holding up with gizmo facing you
        50. const int X_POSITION = 1;
        51. const int Y_POSITION = 2;
        52. const int Z_POSITION = 0;
        53. const bool INVERT_X = true;
        54. const bool INVERT_Y = true;
        55. const bool INVERT_Z = false;
        56. #endif
        57.  
        58. #include "constants.h"
        59.  
        60. // A buffer holding the last 200 sets of 3-channel values
        61. float save_data[600] = {0.0};
        62. // Most recent position in the save_data buffer
        63. int begin_index = 0;
        64. // True if there is not yet enough data to run inference
        65. bool pending_initial_data = true;
        66. // How often we should save a measurement during downsampling
        67. int sample_every_n;
        68. // The number of measurements since we last saved one
        69. int sample_skip_counter = 1;
        70.  
        71. uint32_t last_reading_stamp = 0;
        72.  
        73. TfLiteStatus SetupAccelerometer(tflite::ErrorReporter* error_reporter) {
        74.   // Wait until we know the serial port is ready
        75.   //while (!Serial) { yield(); }
        76.  
        77.   arcada.pixels.setBrightness(50); // Set BRIGHTNESS to about 1/5 (max = 255)
        78.  
        79.   arcada.accel->setRange(LIS3DH_RANGE_4_G);
        80.   arcada.accel->setDataRate(LIS3DH_DATARATE_25_HZ);
        81.   float sample_rate = 25;
        82.   
        83.   // Determine how many measurements to keep in order to
        84.   // meet kTargetHz
        85.   sample_every_n = static_cast<int>(roundf(sample_rate / kTargetHz));
        86.  
        87.   error_reporter->Report("Magic starts!");
        88.  
        89.   return kTfLiteOk;
        90. }
        91.  
        92. bool ReadAccelerometer(tflite::ErrorReporter* error_reporter, float* input,
        93.                        int length, bool reset_buffer) {
        94.   // Clear the buffer if required, e.g. after a successful prediction
        95.   if (reset_buffer) {
        96.     memset(save_data, 0, 600 * sizeof(float));
        97.     begin_index = 0;
        98.     pending_initial_data = true;
        99.   }
        100.   // Keep track of whether we stored any new data
        101.   bool new_data = false;
        102.   // Loop through new samples and add to buffer
        103.   while (arcada.accel->haveNewData()) {
        104.     float x, y, z;
        105.     
        106.     // Read each sample, removing it from the device's FIFO buffer
        107.     sensors_event_t event; 
        108.     
        109.     if (! arcada.accel->getEvent(&event)) {
        110.       error_reporter->Report("Failed to read data");
        111.       break;
        112.     }
        113.     
        114.     // Throw away this sample unless it's the nth
        115.     if (sample_skip_counter != sample_every_n) {
        116.       sample_skip_counter += 1;
        117.       continue;
        118.     }
        119.     
        120.     float values[3] = {0, 0, 0};
        121.     values[X_POSITION] = event.acceleration.x / 9.8;
        122.     values[Y_POSITION] = event.acceleration.y / 9.8;
        123.     values[Z_POSITION] = event.acceleration.z / 9.8;
        124.  
        125.     x = values[0];
        126.     y = values[1];
        127.     z = values[2];
        128.  
        129.     if (INVERT_X) {
        130.       x *= -1;
        131.     }
        132.     if (INVERT_Y) {
        133.       y *= -1;
        134.     }
        135.     if (INVERT_Z) {
        136.       z *= -1;
        137.     }
        138.     Serial.print(x, 2);
        139.     Serial.print(", "); Serial.print(y, 2);
        140.     Serial.print(", "); Serial.println(z, 2);
        141.     
        142.     last_reading_stamp = millis();
        143.     // Write samples to our buffer, converting to milli-Gs
        144.     save_data[begin_index++] = x * 1000;
        145.     save_data[begin_index++] = y * 1000;
        146.     save_data[begin_index++] = z * 1000;
        147.     
        148.     // Since we took a sample, reset the skip counter
        149.     sample_skip_counter = 1;
        150.     // If we reached the end of the circle buffer, reset
        151.     if (begin_index >= 600) {
        152.       begin_index = 0;
        153.     }
        154.     new_data = true;
        155.   }
        156.  
        157.   // Skip this round if data is not ready yet
        158.   if (!new_data) {
        159.     return false;
        160.   }
        161.  
        162.   // Check if we are ready for prediction or still pending more initial data
        163.   if (pending_initial_data && begin_index >= 200) {
        164.     pending_initial_data = false;
        165.   }
        166.  
        167.   // Return if we don't have enough data
        168.   if (pending_initial_data) {
        169.     return false;
        170.   }
        171.  
        172.   // Copy the requested number of bytes to the provided input tensor
        173.   for (int i = 0; i < length; ++i) {
        174.     int ring_array_index = begin_index + i - length;
        175.     if (ring_array_index < 0) {
        176.       ring_array_index += 600;
        177.     }
        178.     input[i] = save_data[ring_array_index];
        179.   }
        180.  
        181.   return true;
        182. }

While the LED/Display output is done in the **output_handler.cpp**
 Download: [Project Zip](https://learn.adafruit.com/pages/17904/elements/3046771/download?type=zip) or [arduino_output_handler.cpp](https://learn.adafruit.com/pages/17904/elements/3046771/download) |  [View on Github](https://github.com/adafruit/Adafruit_TFLite/blob/master/examples/magic_wand_arcada/arduino_output_handler.cpp)
[Copy Code](https://learn.adafruit.com/tensorflow-lite-for-edgebadge-kit-quickstart/gesture-demo#)

        1. /* Copyright 2019 The TensorFlow Authors. All Rights Reserved.
        2.  
        3. Licensed under the Apache License, Version 2.0 (the "License");
        4. you may not use this file except in compliance with the License.
        5. You may obtain a copy of the License at
        6.  
        7.     http://www.apache.org/licenses/LICENSE-2.0
        8.  
        9. Unless required by applicable law or agreed to in writing, software
        10. distributed under the License is distributed on an "AS IS" BASIS,
        11. WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
        12. See the License for the specific language governing permissions and
        13. limitations under the License.
        14. ==============================================================================*/
        15.  
        16. #include "output_handler.h"
        17.  
        18. #include "Arduino.h"
        19. #include "Adafruit_Arcada.h"
        20.  
        21. extern Adafruit_Arcada arcada;
        22.  
        23.  
        24. void HandleOutput(tflite::ErrorReporter* error_reporter, int kind) {
        25.   // The first time this method runs, set up our LED
        26.   static int last_kind = -1;
        27.   
        28.   static bool is_initialized = false;
        29.   if (!is_initialized) {
        30.     pinMode(LED_BUILTIN, OUTPUT);
        31.     is_initialized = true;
        32.   }
        33.   // Toggle the LED every time an inference is performed
        34.   static int count = 0;
        35.   ++count;
        36.   if (count & 1) {
        37.     digitalWrite(LED_BUILTIN, HIGH);
        38.   } else {
        39.     digitalWrite(LED_BUILTIN, LOW);
        40.   }
        41.  
        42.   // Print some ASCII art for each gesture
        43.   if (kind == 0) {
        44.     error_reporter->Report(
        45.         "WING:\n\r*         *         *\n\r *       * *       "
        46.         "*\n\r  *     *   *     *\n\r   *   *     *   *\n\r    * *       "
        47.         "* *\n\r     *         *\n\r");
        48.     ImageReturnCode stat = arcada.drawBMP((char *)"wing.bmp", 0, 0);
        49.     if (stat != IMAGE_SUCCESS) {
        50.       arcada.display->fillScreen(ARCADA_BLACK);
        51.       arcada.display->setCursor(20, 20);
        52.       arcada.display->setTextColor(ARCADA_YELLOW);
        53.       arcada.display->setTextSize(ceil(arcada.display->width() / 30));
        54.       arcada.display->print("WING");
        55.     }
        56.     arcada.WavPlayComplete("wing.wav");
        57.     arcada.pixels.fill(arcada.pixels.Color(50, 50, 0));
        58.     arcada.pixels.show();
        59.   } else if (kind == 1) {
        60.     error_reporter->Report(
        61.         "RING:\n\r          *\n\r       *     *\n\r     *         *\n\r "
        62.         "   *           *\n\r     *         *\n\r       *     *\n\r      "
        63.         "    *\n\r");
        64.     ImageReturnCode stat = arcada.drawBMP((char *)"ring.bmp", 0, 0);
        65.     if (stat != IMAGE_SUCCESS) {
        66.       arcada.display->fillScreen(ARCADA_BLACK);
        67.       arcada.display->setCursor(20, 20);
        68.       arcada.display->setTextColor(ARCADA_PURPLE);
        69.       arcada.display->setTextSize(ceil(arcada.display->width() / 30));
        70.       arcada.display->print("RING");
        71.     }
        72.     arcada.WavPlayComplete("ring.wav");
        73.     arcada.pixels.fill(arcada.pixels.Color(50, 0, 50));
        74.     arcada.pixels.show();
        75.   } else if (kind == 2) {
        76.     error_reporter->Report(
        77.         "SLOPE:\n\r        *\n\r       *\n\r      *\n\r     *\n\r    "
        78.         "*\n\r   *\n\r  *\n\r * * * * * * * *\n\r");
        79.     ImageReturnCode stat = arcada.drawBMP((char *)"slope.bmp", 0, 0);
        80.     if (stat != IMAGE_SUCCESS) {
        81.       arcada.display->fillScreen(ARCADA_BLACK);
        82.       arcada.display->setCursor(20, 20);
        83.       arcada.display->setTextColor(ARCADA_BLUE);
        84.       arcada.display->setTextSize(ceil(arcada.display->width() / 40));
        85.       arcada.display->print("SLOPE");
        86.     }
        87.     arcada.WavPlayComplete("slope.wav");
        88.     arcada.pixels.fill(arcada.pixels.Color(0, 50, 50));
        89.     arcada.pixels.show();
        90.   } else {
        91.     if (last_kind <= 2) {
        92.       // re-draw intro
        93.       ImageReturnCode stat = arcada.drawBMP((char *)"howto.bmp", 0, 0);
        94.       if (stat != IMAGE_SUCCESS) {
        95.         arcada.display->fillScreen(ARCADA_BLACK);
        96.         arcada.display->setCursor(0, 0);
        97.         arcada.display->setTextColor(ARCADA_WHITE);
        98.         arcada.display->setTextSize(ceil(arcada.display->width() / 180.0));
        99.         arcada.display->println("With screen facing");
        100.         arcada.display->println("you, move board in");
        101.         arcada.display->println("the shape of a");
        102.         arcada.display->println("W, clockwise O or L");
        103.       }
        104.       arcada.pixels.fill(0);
        105.       arcada.pixels.show();
        106.     }
        107.   }
        108.   last_kind = kind;
        109. }

อ้างอิง https://learn.adafruit.com/tensorflow-lite-for-edgebadge-kit-quickstart/gesture-demo

วิดีโอตัวอย่างหลังทำเสร็จ
https://cdn-learn.adafruit.com/assets/assets/000/084/219/large1024mp4/adafruit_products_badge.mp4?1573775335



# ตัวอย่างงานที่1[Project lemon]

Special for TESA#15
สรุปให้สั้นที่สุดมันคือการคัดแยกมะนาวบนสายพาน โดยบอร์ด Raspberry pi ต่อกล้อง ปกติเวลาคัดแยกมะนาวเนี่ยเราต้องใช้คนคัดแต่ตอนนี้เรามีAI computor vision แล้ว ถึงเวลาทำประโยชน์ให้สังคม


## ภาคที่1 พ่อมดแห่งข้อมูล “รู้เขารู้เรา รบร้อยครั้งชนะร้อยครา” อันกลการรบนั้นเกิดจากการศึกษาข้อมูล

ก่อนอื่นเราต้องมีข้อมูล เพราะไม่เช่นนั้นถ้าไม่สอนอะไร น้องAI จะรู้ได้ไงว่า”มะนาว”นี่มันหน้าตาเป็นยังไง(ยกเว้น Reinforce นะ)

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537085672_Screen+Shot+2564-02-17+at+11.44.36.png)


ซึ่งข้อมูลที่ว่าก็คือรูปมะนาวจำนวนมหาศาล…

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537155284_Screen+Shot+2564-02-17+at+11.45.42.png)


มะนาว? ใช่มันคือรูปมะนาวจำนวนมหาศาล ซึ่งยังใช้ไม่ได้…
ใครพูดถึงการ label มือกัน โอเคถ้าคุณมีความอดทนพอ แต่ว่าเรามีตัวเลือกที่น่าสนใจมาเสนอ
นั่นก็คือ!!!

https://github.com/tzutalin/labelImg


โปรแกรม Python ที่ช่วย label รูป!!!

แต่เดี๋ยวก่อน! คือจริงๆคุณนั่นแหละที่ต้อง label แต่ง่ายขึ้นไง ดีเลยเนอะ?

หลังจากนี้คือการใช้แรงงาน…

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537410803_Screen+Shot+2564-02-17+at+11.50.01.png)


ดูจำนวนรูปสิ อย่าไปสนใจชื่อไฟล์เลย…

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537566594_Screen+Shot+2564-02-17+at+11.52.29.png)


สิ่งที่คุณต้องทำก็คือ คลิกเจ้าปุ่มล้อมกรอบนี่ มันจะให้คุณวงมะนาวในรูป

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537622695_Screen+Shot+2564-02-17+at+11.53.33.png)


เด้งขึ้นมาให้ใส่ชื่อคลาส ในที่นี้คลาสคือ”lemon” = มะนาว

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537734400_Screen+Shot+2564-02-17+at+11.54.41.png)


กด save

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537791294_Screen+Shot+2564-02-17+at+11.56.07.png)


กดภาพถัดไป…


![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613537809382_Screen+Shot+2564-02-17+at+11.56.14.png)


แล้วหลังจากนั้นเวลาก็จะผ่านไปนานแสนนาน กาลครั้งหนึ่งน๊าน นาน นาน…
มะนาวลูกที่1 มะนาวลูกที่2 มะนาวลูกที่…
คำเตือน:อย่าพยายามLabel รูปจำนวนมากคนเดียวแบบนี้ จะกลายเป็นAiluropoda melanoleuca(หมีแพนด้า)เอาได้ ผู้เขียนขอเตือนว่าอย่าเลยเชียว

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613538127468_Screen+Shot+2564-02-17+at+12.01.43.png)

                                “ความสำเร็จเป็นดอกผลของความพยายาม"

โอ้…แต่ไฟล์ข้างบนนี่น่ะเป็นบันไดสู่ความสำเร็จ ยังไม่ใช่ความสำเร็จหรอกนะ
เพราะหนทางยังอีกยาวไกล

ขั้นต่อไปแปลงไฟล์เป็น .csv เพื่อความง่ายในการอ่านก่อนค่ะ
คุณสามารถดูได้จากVideo นี้ที่ผู้เขียนได้จากกัลยาณมิตรที่แสนจะงดงาม

https://www.youtube.com/watch?v=Rgpfk6eYxJA&


[https://youtu.be/Rgpfk6eYxJA](https://youtu.be/Rgpfk6eYxJA)

จากGithub นี้ กดเข้าไปเลยจ้า


https://github.com/EdjeElectronics/TensorFlow-Object-Detection-API-Tutorial-Train-Multiple-Objects-Windows-10


คุณจะพบกับไฟล์

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613538460278_Screen+Shot+2564-02-17+at+12.07.27.png)


นี่ล่ะค่ะตัวเปลี่ยน เอามาอ่านกันหน่อยดีกว่า

    import os
    import glob
    import pandas as pd
    import xml.etree.ElementTree as ET
    
    
    def xml_to_csv(path):
        xml_list = []
        for xml_file in glob.glob(path + '/*.xml'):
            tree = ET.parse(xml_file)
            root = tree.getroot()
            for member in root.findall('object'):
                value = (root.find('filename').text,
                         int(root.find('size')[0].text),
                         int(root.find('size')[1].text),
                         member[0].text,
                         int(member\[4\][0].text),
                         int(member\[4\][1].text),
                         int(member\[4\][2].text),
                         int(member\[4\][3].text)
                         )
                xml_list.append(value)
        column_name = ['filename', 'width', 'height', 'class', 'xmin', 'ymin', 'xmax', 'ymax']
        xml_df = pd.DataFrame(xml_list, columns=column_name)
        return xml_df
    
    
    def main():
        for folder in ['train','test']:
            image_path = os.path.join(os.getcwd(), ('images/' + folder))
            xml_df = xml_to_csv(image_path)
            xml_df.to_csv(('images/' + folder + '_labels.csv'), index=None)
            print('Successfully converted xml to csv.')
    
    
    main()

นี่ล่ะค่ะข้างในของไฟล์นี้

หลังจากที่เรารู้ว่าส่วนไหนของภาพคือมะนาวขั้นถัดไปคือการนำมาใช้กับAI
อย่ารอช้านี่คือ Colab จากTesa#15 นำมาใช้เพื่อประโยชน์ทางการศึกษาค่ะ


https://colab.research.google.com/drive/1yDCvX9WC-dIDXvn5ao_mt8V1Qy620LI3#scrollTo=_aZCMR5vFKHG

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613538689913_Screen+Shot+2564-02-17+at+12.11.18.png)


นี่ล่ะค่ะ จุดเริ่มต้น…
จริงๆถ้ามีเวลาอยากสร้างฉบับสรุปให้ติดตามกันได้นะคะ กำไฟล์ csv ในมือของคุณเอาไว้เรามีข้อมูล และกำลังจะ To be continue… ค่ะ!!!

ก่อนจะไปต่อขอเชิญอ่านแบบฝึกหัดก่อนค่ะ

## งานที่1 ลอง Label ข้อมูลโดยใช้ LabelImg

Dataset [link]
โปรแกรมLabelImg [link]
โจทย์Label ข้อมูลภาพที่กำหนดให้เพื่อใช้ในขั้นต่อไป วัตถุประสงค์เพื่อความเข้าใจและการลงมือLabelข้อมูลจริง(10 คะแนน) โดยจะนับคะแนนจากการlabelข้อมูลที่มีคุณภาพถูกวัตถุประสงค์ใช้ในการTrainได้ผลความแม่นยำตรงวัตถุประสงค์อันจะปรากฎเป็นรูปธรรมในขั้นถัดไป





## ภาคที่2 ยัย AI ตัวร้าย กับนายข้อมูล csv เราจะเข้าใจกันได้ยังไง?

สรุป มันคือการยัดข้อมูลใส่AIค่ะ จะให้โยนโคร้มไปน้องAI งงเลยนี่มันอะไร?? คือจะให้ทำอะไร? 479? lemon?
หน้าตาข้อมูลก่อนเรียงเป็น csv คือแบบนี้ค่ะ


![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1613539377654_Screen+Shot+2564-02-17+at+12.22.47.png)


อย่าว่าแต่ AI เลยค่ะ ถ้าไม่จัดเรียงแม้แต่คนยังงงเลยค่ะ

A:แต่เราเรียงเป็น csv แล้วนะ
B:แต่มันก็แบบนี้แหละแค่เป็นตารางนะ
AI: … #?/????!

ข้อแรกคือโจทย์นี้มีความcomputor vision สูงมาก


