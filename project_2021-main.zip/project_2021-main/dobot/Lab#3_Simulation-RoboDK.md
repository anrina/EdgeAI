# Lab#3_Simulation-RoboDK

# basic guide RoboDK

RoboDK เป็น software ที่ช่วยในการทำ Offline Programming สำหรับเขียนโปรแกรมสั่งการ Robot โดย RoboDK สามารถทำ Simulation ในการจำลองการทำงานของ Robot, Censor, สายพานลำเลียง, ชิ้นงาน และอุปกรณ์อื่นๆ เพื่อตรวจสอบความถูกต้องของ Robot และ RoboDK เป็น Software ที่ใช้งานง่าย ช่วยให้ผู้วางระบบ Automation ด้าน Robot สามารถบริหารจัดการแผนผังในกานทำงานของระบบ คำนวณเวลาการผลิต และสามารถเขียนโปรแกรมสั่งการ Robot ได้อีกด้วย


## Robot Machining

RoboDK รองรับการทำงานของ Arm Robots ได้ถึง 5 แกน สำหรับ Milling เพียงแค่เลือกประเภทของ Robot นำเข้าชิ้นงาน 3D ทำการกำหนด Tool แต่ละโปรแกรมเพียงเท่านี้ Software RoboDK ก็สามารถคำนวณ Toolpath ให้และทำแบบจำลอง Simulation เพื่อให้เห็นการทำงานจริงของ Robot ก่อนที่จะแปลงคำสั่งออกมาเป็น NC Code (G-code, APT or DXF files) นอกจากนี้ RoboDK สามารถตรวจสอบการชนระหว่าง Tooling, ชิ้นงาน, jig fixture และอื่นๆที่อยู่ในสภาพแวดล้อมเดียวกันได้อีกด้วย 


## Robot Library

RoboDK สามารถเข้าถึง Library ของ Robot ได้อย่างกว้างขวาง รวมถึง Tools ต่างๆ อีกมากมาย ซึ่งเป็นเรื่องที่ง่ายมากที่จะใช้ RoboDK กับ Robot หลากหลายยี่ห้อ และ หลากหลาย application ไม่ว่าจะเป็น งาน pick and place , welding, cutting, painting, inspection, deburring และอื่นๆอีกมากมาย


## Robot Accuracy 

RoboDK มีระบบที่ช่วยระบุพารามิเตอร์ทางเลขาคณิต (Real geometrical parameter) ที่มีชื่อว่า Robot Calibration เพื่อช่วยปรับปรุงความแม่นยำในส่วนต่างๆที่มีความสัมพันธ์กันเชื่อมต่อถึงกัน ให้สามารถทำงานร่วมกันได้อย่างมีประสิทธิภาพ
RoboDK ยังมีระบบช่วยวัดความถูกต้องของ Robot ที่ชื่อว่า Robot ballbar test ช่วยให้คุณสามารถว้ดความถูกต้องของหุ่นยนต์ได้โดยใช้อุปกรณ์วัด telescoping ballbar

## Reference Frames 

Reference Frames จะกำหนดตำแหน่งของ item และ position โดย item อาจจะเป็นวัตถุหรือหุ่นยนต์ ซึ่งการ simulate นั้นต้องกำหนด reference frames เพื่อการ simulate ที่เหมาะสม และจะมี station tree เพื่อกำหนดความสัมพันธ์ เช่น reference frames ที่ซ้อนกัน 

----------
# ขั้นตอนการติดตั้งโปรแกรม RoboDK


1. ติดตั้งโปรแกรมได้จากลิ้งค์ —> https://robodk.com/download
    **ดาวโหลดตามสเปคของเครื่องแต่ละคน


![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612164861657_image.png)



2. กด Next
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166850008_Screenshot+from+2021-02-01+15-05-10.png)

3. เลือก path ที่เราต้องการติดตั้ง แล้วกด next
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166879018_Screenshot+from+2021-02-01+15-05-19.png)

4. กดติดตั้ง software และกด next
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166887975_Screenshot+from+2021-02-01+15-05-24.png)

5. กด accept แล้วกด next
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166899565_Screenshot+from+2021-02-01+15-05-31.png)

6. รอจนติดตั้งเสร็จ
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166927573_Screenshot+from+2021-02-01+15-05-40.png)

7. แล้วกด finish เพื่อ run โปรแกรม 
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166936151_Screenshot+from+2021-02-01+15-06-29.png)

8. โปรแกรม RoboDK ใช้งานได้ 
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612166943802_Screenshot+from+2021-02-01+15-06-41.png)



----------
## RoboDK API

RoboDK API (Application Program Interface) คือคำสั่งที่ RoboDK เปิดผ่านภาษาโปรแกรม ซึ่ง RoboDK API ช่วยให้สามารถโปรแกรมหุ่นยนต์โดยใช้ภาษาโปรแกรมที่รองรับเช่น C#, Python หรือ C++ 
RoboDK  มี Graphical User Interface (GUI) ที่ใช้งานง่ายเพื่อจำลองและตั้งโปรแกรมหุ่นยนต์ระดับอุตสาหกรรม ไม่จำเป็นต้องมีประสบการณ์การเขียนโปรแกรมเพื่อจำลองและ RoboDK API นั้นไม่มีข้อจำกัด สำหรับการจำลองและเขียนโปรแกรมแบบ offline 
หมายเหตุ :  API สามารถใช้งานได้ในภาษาโปรแกรมใดก็ได้ ซึ่ง API นั้นประกอบด้วยโปรโตคอล TCP/IP ที่ใช้งานใน RoboDK เมื่อ RoboDK กำลังทำงานมันจะทำงานเหมือนเซิร์ฟเวอร์ และจะเปิดเผยชุดคำสั่งผ่านโปรโตคอล TCP/IP

RoboDK API สามารถใช้สำหรับงานต่อไปนี้ 

1. ทำให้การ simulation เป็นโดยอัตโนมัติ ซึ่งมันสร้าง macros เพื่อทำงานเฉพาะภายในโปรแกรมจำลอง RoboDK โดยอัตโนมัติ เช่นการเคลื่อนย้ายวัตถุ, reference frame และ หุ่นยนต์
2. Offline programming: การเขียนโปรแกรมหุ่นยนต์แบบ offline จากภาษาโปรแกรมต่างๆ RoboDK จะสร้างโปรแกรมเฉพาะสำหรับตัวควบคุมหุ่นยนต์เฉพาะเมื่อใช้ API (เช่นโปรแกรมใน Python หรือ C#) โปรแกรมหุ่นยนต์ถูกสร้างขึ้นตาม post processor ที่เลือกสำหรับหุ่นยนต์ 
3. Online Programming: การเขียนโปรแกรมหุ่นยนต์แบบ online โดยใช้ภาษาโปรแกรมต่างๆ นั้นสามารถเคลื่อนย้ายหุ่นยนต์และดึงตำแหน่งปัจจุบันจาก RoboDK API ได้ RoboDK จะบังคับหุ่นยนต์โดยใช้ Driver 


## Python API

Python เป็นภาษาโปรแกรมระดับสูงที่ใช้อย่างแพร่หลายสำหรับการเขียนโปรแกรม ซึ่งวัตถุประสงค์ทั่วไปของ Python นั้นเป็นภาษาโปรแกรมที่ช่วยให้ทำงานเร็วขึ้นและรวมระบบได้อย่างประสิทธิภาพมากขึ้น และ syntax ของ ภาษาpython นั้นช่วยให้โปรแกรมเมอร์สามารถเขียนโค้ดให้น้อยลงเมื่อเทียบกับภาษาอื่นๆ ทำให้ง่ายต่อการเรียนรู้
โดย Python ถูกติดตั้งและรวมเข้ากับ RoboDK โดยอัตโนมัติมาตั้งแต่ค่าเริ่มต้นอยู่แล้ว โดยเราเพียงแค่เลือกไปที่ tools → options → other to change the default setting (python location and python editor)

----------
# Getting Started
1. file → newstation
![](https://paper-attachments.dropbox.com/s_8EFEBAA4B5B84325268510BE98012D4AB13C37BD9779698F37F5712514DA8E8A_1612596544465_S__6160445.jpg)

2. เลือก robot โดยไปที่ file → open online library 
![](https://paper-attachments.dropbox.com/s_8EFEBAA4B5B84325268510BE98012D4AB13C37BD9779698F37F5712514DA8E8A_1612596557614_S__6160446.jpg)



3. เลือก Dobot Magician 
![](https://paper-attachments.dropbox.com/s_8EFEBAA4B5B84325268510BE98012D4AB13C37BD9779698F37F5712514DA8E8A_1612596564711_S__6160447.jpg)

----------
## Add a Reference Frame
1. เลือก program → add reference frame 
![](https://paper-attachments.dropbox.com/s_8EFEBAA4B5B84325268510BE98012D4AB13C37BD9779698F37F5712514DA8E8A_1612597044519_S__6160448.jpg)

![](https://paper-attachments.dropbox.com/s_8EFEBAA4B5B84325268510BE98012D4AB13C37BD9779698F37F5712514DA8E8A_1612597055722_S__6160449.jpg)

2. double click ที่  reference frame เพื่อป้อนพิกัดตำแหน่ง X, Y, Z และมุม Euler สำหรับการวางแนว(orientation) โดยค่าเริ่มต้นอ้างอิงดังนี้
- พิกัด X → Red
- พิกัด Y → Green
- พิกัด Z → Blue
- 1st Euler rotation → Cyan
- 2nd Euler rotation → Magenta
- 3rd Euler rotation → Yellow
![](https://paper-attachments.dropbox.com/s_8EFEBAA4B5B84325268510BE98012D4AB13C37BD9779698F37F5712514DA8E8A_1612597071253_S__6160450.jpg)



3. เลือก view → Make reference frames bigger (+) เพื่อเพิ่มขนาดของ reference frames
4. เลือก view → Make reference frames smaller (-) เพื่อลดขนาดของ reference frames
5. เลือก View → Show/Hide text on screen (/) เพื่อแสดงหรือซ่อนข้อความบนหน้าจอ
----------
# เริ่มใช้งาน RoboDK กับ Dobot Magician


1. เปิด Online library


![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612164751285_image.png)

2. เลือก Brand Dobot
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612168107661_image.png)

3. เลือก Dobot Magician แล้วกด Download
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612164682962_image.png)

4. จะได้ตัว robot , reference frame ตามรูป
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612171454228_image.png)


คลิ๊ก mouse กลาง + ลาก เลื่อนตำแหน่งอุปกรณ์

![ก่อน](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612171499916_image.png)
![หลัง](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612171515427_image.png)


คลิ๊ก mouse ขวา + ลาก หมุนอุปกรณ์

![ก่อน](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612171642142_image.png)
![หลัง](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612171663846_image.png)


scroll ขึ้น-ลง zoom เข้า-ออก

![เข้า](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612172345191_image.png)
![ออก](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612172325706_image.png)



----------
# เริ่มต้นการ program python

ในโปรแกรม Robo DK จะมีการให้โปรแกรมภาษาpython(กดสัญลักษณ์ทางซ้าย) และการโปรแกรมที่link กับตัว robot เป็นตัวๆไป(กดสัญลักษณ์ทางขวา)

![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1612177021320_Screen+Shot+2564-02-01+at+17.55.00.png)


ในที่นี้จะเป็นสัญลักษณ์ทางซ้ายคือ การโปรแกรมโดยใช้ภาษาpython
โดยถ้าเรากดบวกมาเฉยๆเมื่อกดrun program ครั้งแรกจะขึ้นแจ้งเตือนให้ตั้งค่าปรับดังนี้


![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1612177186311_Screen+Shot+2564-02-01+at+17.55.24.png)


เมื่อปรับเปลี่ยนตามแล้วก็จะมาถึงส่วนของcode เบื้องต้นที่ใส่มาให้


![](https://paper-attachments.dropbox.com/s_EF79ABF7D89762B09F442B3911ADA0F16CACE2AF4A4F4AC1ED250F018B92A8CD_1612177223322_Screen+Shot+2564-02-01+at+17.55.52.png)


ซึ่งก็ไม่มีอะไรเลยนอกจาก print แสดงข้อมูล

ทางผู้เขียนจึงไปนำ code การวาดรูป hexagon 
มาจากแหล่งอ้างอิง https://robodk.com/offline-programming
โดยเป็นการใช้ RoboDK API

            1. # Draw a hexagon around Target 1
            2. from robolink import *    # RoboDK's API
            3. from robodk import *      # Math toolbox for robots
            4.  
            5. # Start the RoboDK API:
            6. RDK = Robolink()
            7.  
            8. # Get the robot (first robot found):
            9. robot = RDK.Item('', ITEM_TYPE_ROBOT)
            10.  
            11. # Get the reference target by name:
            12. target = RDK.Item('Target 1')
            13. target_pose = target.Pose()
            14. xyz_ref = target_pose.Pos()
            15.  
            16. # Move the robot to the reference point:
            17. robot.MoveJ(target)
            18.  
            19. # Draw a hexagon around the reference target:
            20. for i in range(7):
            21.     ang = i*2*pi/6 # Angle = 0,60,120,...,360
            22.     R = 200        # Polygon radius
            23.     
            24.     # Calculate the new position:
            25.     x = xyz_ref[0] + R*cos(ang) # new X coordinate
            26.     y = xyz_ref[1] + R*sin(ang) # new Y coordinate
            27.     z = xyz_ref[2]              # new Z coordinate
            28.     target_pose.setPos([x,y,z])
            29.     
            30.     # Move to the new target:
            31.     robot.MoveL(target_pose)
            32.  
            33. # Trigger a program call at the end of the movement
            34. robot.RunInstruction('Program_Done')
            35.  
            36. # Move back to the reference target:
            37. robot.MoveL(target)

เราจะเห็นได้ว่ามีการใช้การคำนวนทางคณิตศาสตร์ อ้างอิงบททฤษฎีทางเรขาคณิตเพื่อใช้ในการโปรแกรมคำนวนการเคลื่อนที่ในแต่ละloop ซึ่งการคำนวนเกี่ยวกับตำแหน่งของแขนกลนั้นผู้ศึกษาควรมีความรู้เบื้องต้นเกี่ยวกับคณิตศาสตร์โดยจากตัวอย่างที่ปรากฎนี้จะเห็นได้ว่าใช้คณิตศาสตร์คำนวนมุมภายในและหาระยะด้านการเคลื่อนที่จากรัศมีที่กำหนดได้

----------
# ทดลองใส่ Tool ให้กับ Robot 


![รายละเอียดของ robot](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612238349836_image.png)

![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612239600643_image.png)

![ใน library ไม่มีตัว gripper ที่ไว้ใช้เฉพาะกับ Dobot Magician](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612239632864_image.png)

----------


# อธิบายตัวอย่างที่ 1
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612765965908_image.png)



![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612768832186_image.png)


Example นี้ จะใช้ ตัว Robot Mecademic Meca500 R2 ติดกับ Gripper หยิบ box บน table ไปวางอีกจุดหนึ่งใน table เดิม


## ข้อมูลใน station
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612846910298_image.png)

## Part ของตัว robot ,tool และ object

Robot

- Mecademic Meca500 R2

Tool

- Gripper (Finger A/B สองข้างของ Gripper)

Object

- Table
- box


![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612846921277_image.png)

## Part ของ Target
- Home จุดเริ่มต้น
- Pick Approach จุด robot จะขยับมาจาก Home ก่อนที่จะลงไปต่อเพื่อ pick object (box)
- Pick จุดที่จะทำการ pick จะมี object (box ) วางอยู่
- Place Approach จุดที่ robot จะขยับมาจาก Home ก่อนที่จะลงไปต่อเพื่อ pick object (box)
- Place จุดที่จะทำการ place object (box ) 
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612779216220_image.png)



![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612846928964_image.png)

## Part ของ Program และ Instruction

**Program** 
 code  Gripper.py

    This program allows moving gripper fingers
    import sys # allows getting the passed argument parameters
    from robodk import *
    if len(sys.argv) < 2:
    print('Invalid parameters. This function must be called as MoveGripper(Gripper_Id, Distance)')
    print('Number of arguments: ' + str(len(sys.argv)))
    #raise Exception('Invalid parameters provided: ' + str(sys.argv))
    entry = mbox('Move gripper. Type:\n1 to open, 0 to close\n\nNote: this can be called as a program.\nExample: Gripper(1)', entry='0')
    if not entry:
    raise Exception('Operation cancelled by user')
    GRIPPER_VALUE = int(entry)*6
    else:
    GRIPPER_VALUE = int(sys.argv[1])*6
    from robolink import * # API to communicate with RoboDK
    RDK = Robolink()
    finger_P = RDK.Item('FingerB')
    finger_N = RDK.Item('FingerA')
    if not finger_P.Valid() or not finger_N.Valid():
    raise Exception('Invalid Gripper ID')
    finger_P.setPose(transl(0,+GRIPPER_VALUE,0))
    finger_N.setPose(transl(0,-GRIPPER_VALUE,0))
    Set the station parameter
    RDK.setParam('Gripper', GRIPPER_VALUE)

สวัสดีจ้า😄 วันนี้ขอนำเสนอการอธิบายcode ที่สดใสที่สุดในโลกค่ะ
ภาพรวมคือโปรแกรมนี้เป็นprogramที่ใช้ขยับนิ้วที่ใช้ในการจับสิ่งของของตัวgripper ค่ะ ถ้าเทียบเป็นมนุษย์ก็คือการขยับนิ้วเพื่อจับหรือปล่อยสิ่งของค่ะ ซึ่งมีความสำคัญอย่างยิ่งว่าแล้วก็มาศึกษากันเลยค่ะ




**Instruction**
Gripperclose [สั่งให้ขา Gripper หนีบลง]

- Call Gripper(0) [ใช้งาน Gripper.py โดยใส่ input เป็น 0]
- Attach to Gripper [สั่งให้ขา gripper จับ box แล้วตัว gripper กับ box ขยับไปพร้อมกัน]
- Pause 500 ms [สั่งให้หยุด 500 ms]


Gripperopen [สั่งให้ขา Gripper กางออก]

- Call Gripper(1) [ใช้งาน Gripper.py โดยใส่ input เป็น 1]
- Detach to Gripper [สั่งให้ขา gripper ปล่อย box ไว้แล้วแยกจากกัน]
- Pause 500 ms [สั่งให้หยุด 500 ms]

ResetSimulation

- Replace objects [ย้าย object ที่เลือกไว้ กลับจุดเริ่มต้น]
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1612933238816_image.png)


ProgramTest [(การเคลื่อนไหวของ robot ทั้งหมด]

![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1613229485141_image.png)


Call ResetSimulation  [ใช้งาน ResetSimulation] (ย้าย object กลับไปจุดเริ่มต้น)
Set Ref.: Table 1  [Set reference ที่ใช้เป็นของ Table]
Set Tool: Gripper  [Set Tool ที่ใช้เป็น Gripper]
Call GripperOpen [ใช้งาน GripperOpen] (สั่งให้ขา Gripper กางออก)
MoveJ (Home)  [Move Gripper  แบบขยับ joint  ไปที่ target  Home] 
MoveJ (Pick Approach)   [Move Gripper แบบขยับ joint  ไปที่ target  Pick Approach] 
MoveL (Pick)  [Move Gripper แบบไม่ขยับ joint  ไปที่ target  Pick] 
Call GripperClose [ใช้งาน GripperClose]  (สั่งให้ขา Gripper หนีบลง)
MoveL (Pick Approach) [Move Gripper แบบไม่ขยับ joint  ไปที่ target  Pick Approach] 
MoveL (Place Approach) [Move Gripper แบบไม่ขยับ joint  ไปที่ target  Place Approach] 
MoveL (Place) [Move Gripper แบบไม่ขยับ joint  ไปที่ target  Place] 
Call GripperOpen [ใช้งาน GripperOpen] (สั่งให้ขา Gripper กางออก)
MoveL (Place Approach) [Move Gripper แบบไม่ขยับ joint  ไปที่ target  Place Approach] 
MoveJ (Home) [Move Gripper แบบขยับ joint  ไปที่ target  Home] 

สรุปคือ 
ย้าย object กลับจุดเริ่มต้น แล้วหยิบไปวางอีกจุดนึง แล้วนำแขนกลับมาจุดแรก


https://www.dropbox.com/s/84ckhyg2k0rhoxi/RoboDK%20-%20EX%20pick%20and%20place%20-%20Free%20%28Limited%29%202564-02-10%2010-47-14.mp4?dl=0

# อธิบายตัวอย่างที่ 2
![](https://paper-attachments.dropbox.com/s_38F319CD15728D29AE4FC3533323541BEC793CC6FFE4BA9E91C174B989C0E76D_1613369904855_image.png)

## Program
    from robolink import *    # API to communicate with RoboDK
    from robodk import *      # robodk robotics toolbox
    
    import sys 
    import os
    import re
    
    PIXELS_AS_OBJECTS = False    # Set to True to generate PDF or HTML simulations that include the drawn path
    TCP_KEEP_TANGENCY = False    # Set to True to keep the tangency along the path
    SIZE_BOARD = [1000, 2000]     # Size of the image. The image will be scaled keeping its aspect ratio
    MM_X_PIXEL = 10             # in mm. The path will be cut depending on the pixel size. If this value is changed it is recommended to scale the pixel object
    IMAGE_FILE = 'World map.svg'             # Path of the SVG image, it can be relative to the current RDK station
    
    #--------------------------------------------------------------------------------
    # function definitions:
    
    def point2D_2_pose(point, tangent):
        """Converts a 2D point to a 3D pose in the XY plane including rotation being tangent to the path"""
        return transl(point.x, point.y, 0)*rotz(tangent.angle())
    
    def svg_draw_quick(svg_img, board, pix_ref):
        """Quickly shows the image result without checking the robot movements."""
        RDK.Render(False)
        count = 0
        for path in svg_img:
            count = count + 1
            # use the pixel reference to set the path color, set pixel width and copy as a reference
            pix_ref.Recolor(path.fill_color)
            if PIXELS_AS_OBJECTS:
                pix_ref.Copy()
            np = path.nPoints()
            print('drawing path %i/%i' % (count, len(svg_img)))
            for i in range(np):
                p_i = path.getPoint(i)
                v_i = path.getVector(i)
    
                # Reorient the pixel object along the path
                pt_pose = point2D_2_pose(p_i, v_i)
                
                # add the pixel geometry to the drawing board object, at the calculated pixel pose
                if PIXELS_AS_OBJECTS:
                    board.Paste().setPose(pt_pose)
                else:
                    board.AddGeometry(pix_ref, pt_pose)
                
        RDK.Render(True)
    
    def svg_draw_robot(svg_img, board, pix_ref, item_frame, item_tool, robot):
        """Draws the image with the robot. It is slower that svg_draw_quick but it makes sure that the image can be drawn with the robot."""
    
        APPROACH = 100  # approach distance in MM for each path    
        home_joints = robot.JointsHome().tolist() #[0,0,0,0,90,0] # home joints, in deg
        if abs(home_joints[4]) < 5:
            home_joints[4] = 90.0
        
        robot.setPoseFrame(item_frame)
        robot.setPoseTool(item_tool)
        robot.MoveJ(home_joints)
        
        # get the target orientation depending on the tool orientation at home position
        orient_frame2tool = invH(item_frame.Pose())*robot.SolveFK(home_joints)*item_tool.Pose()
        orient_frame2tool[0:3,3] = Mat([0,0,0])
        # alternative: orient_frame2tool = roty(pi)
    
        for path in svg_img:
            # use the pixel reference to set the path color, set pixel width and copy as a reference
            print('Drawing %s, RGB color = [%.3f,%.3f,%.3f]'%(path.idname, path.fill_color[0], path.fill_color[1], path.fill_color[2]))
            pix_ref.Recolor(path.fill_color)
            if PIXELS_AS_OBJECTS:
                pix_ref.Copy()
            np = path.nPoints()
    
            # robot movement: approach to the first target
            p_0 = path.getPoint(0)
            target0 = transl(p_0.x, p_0.y, 0)*orient_frame2tool
            target0_app = target0*transl(0,0,-APPROACH)
            robot.MoveL(target0_app)
    
            #if TCP_KEEP_TANGENCY:
            #    joints_now = robot.Joints().tolist()
            #    joints_now[5] = -180
            #    robot.MoveJ(joints_now)
            RDK.RunMessage('Drawing %s' % path.idname);
            RDK.RunProgram('SetColorRGB(%.3f,%.3f,%.3f)' % (path.fill_color[0], path.fill_color[1], path.fill_color[2]))
            for i in range(np):
                p_i = path.getPoint(i)
                v_i = path.getVector(i)       
    
                pt_pose = point2D_2_pose(p_i, v_i)
                
                if TCP_KEEP_TANGENCY:
                    #moving the tool along the path (axis 6 may reach its limits)                
                    target = pt_pose*orient_frame2tool 
                else:
                    #keep the tool orientation constant
                    target = transl(p_i.x, p_i.y, 0)*orient_frame2tool
    
                # Move the robot to the next target
                robot.MoveL(target)
    
                # create a new pixel object with the calculated pixel pose
                if PIXELS_AS_OBJECTS:
                    board.Paste().setPose(pt_pose)
                else:
                    board.AddGeometry(pix_ref, pt_pose)
    
            target_app = target*transl(0,0,-APPROACH)
            robot.MoveL(target_app)
            
        robot.MoveL(home_joints)
    
    #--------------------------------------------------------------------------------
    # Program start
    RDK = Robolink()
    
    # locate and import the svgpy module
    # Old versions of RoboDK required adding required paths to the process path
    # New versions of RoboDK automatically add the current folder to the path (after 4.2.2)
    path_stationfile = RDK.getParam('PATH_OPENSTATION')
    #sys.path.append(os.path.abspath(path_stationfile)) # temporary add path to import station modules
    #print(os.getcwd())
    #print(os.environ['PYTHONPATH'].split(os.pathsep))
    #print(os.environ['PATH'].split(os.pathsep))
    
    
    from svgpy.svg import *
    
    # select the file to draw
    svgfile = IMAGE_FILE
    if len(svgfile) == 0:
        svgfile = getOpenFile()
    elif not FileExists(svgfile):
        svgfile = path_stationfile + '/' + svgfile
        
    #svgfile = path_stationfile + '/World map.svg'
    #svgfile = path_stationfile + '/RoboDK text.svg'
    
    # import the SVG file
    svgdata = svg_load(svgfile)
    
    IMAGE_SIZE = Point(SIZE_BOARD[0],SIZE_BOARD[1])   # size of the image in MM
    svgdata.calc_polygon_fit(IMAGE_SIZE, MM_X_PIXEL)
    size_img = svgdata.size_poly()  # returns the size of the current polygon
    
    # get the robot, frame and tool objects
    robot = RDK.ItemUserPick('', ITEM_TYPE_ROBOT)
    framedraw = RDK.Item('Frame draw')
    tooldraw = RDK.Item('Tool')
    
    # get the pixel reference to draw
    pixel_ref = RDK.Item('pixel')
    
    # delete previous image if any
    image = RDK.Item('Board & image')
    if image.Valid() and image.Type() == ITEM_TYPE_OBJECT: image.Delete()
    
    # make a drawing board base on the object reference "Blackboard 250mm"
    board_1m = RDK.Item('Blackboard 250mm')
    board_1m.Copy()
    board_draw = framedraw.Paste()
    board_draw.setVisible(True, False)
    board_draw.setName('Board & image')
    board_draw.Scale([size_img.x/250, size_img.y/250, 1]) # adjust the board size to the image size (scale)
    
    pixel_ref.Copy()
    
    # quickly show the final result without checking the robot movements:
    #svg_draw_quick(svgdata, board_draw, pixel_ref)
    
    # draw the image with the robot:
    svg_draw_robot(svgdata, board_draw, pixel_ref, framedraw, tooldraw, robot)

ผลการใช้งาน

![รูปต้นแบบ](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1613459484054_World+map.svg)

![รูปที่ได้ (zoom ไกล)](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1613459450949_image.png)


รูปที่ zoom ใกล้ๆ จะเห็นเส้นละเอียดกว่า

![](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1613459541016_image.png)
![](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1613459555864_image.png)

![](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1613459588163_image.png)
![](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1613459569804_image.png)



## อธิบาย Code python

**import**

    from robolink import *   
    from robodk import *

ทุก module จาก robolink และ robodk


    import os

library os ใช้

    import sys
    import re
    from svgpy.svg import *

**define function**

    def point2D_2_pose(point, tangent):

เปลี่ยน ตำแหน่ง x,y ของภาพ เป็นตำแหน่ง x,y,z ของกระดานภาพ


    def svg_draw_quick(svg_img, board, pix_ref):

วาดรูปแบบไม่สนว่าแขน robot ขยับได้ตามนั้นหรือไม่


    def svg_draw_robot(svg_img, board, pix_ref, item_frame, item_tool, robot):

วาดรูปแบบเทียบให้แขน robot เคลื่อนไหวตามได้


ลองเปลี่ยนให้วาดรูปอื่นใน folder






main program


![](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1615202876584_image.png)

![](https://paper-attachments.dropbox.com/s_BECAE7C80B01B84A66CA101A97EAA0A27863A8D527F70CDCEF30C88A902EF4BE_1615202889340_image.png)


