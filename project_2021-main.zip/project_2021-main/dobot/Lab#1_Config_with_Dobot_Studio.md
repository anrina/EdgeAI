# Lab#1_Config_with_Dobot_Studio

## ติดตั้งตัวโปรแกรม Dobot Studio

สามารถ Download ได้ที่
https://www.dobot.cc/downloadcenter/dobot-magician.html#most-download


1. เมื่อดาวโหลดโปรแกรมเสร็จให้ทำการติดตั้งโปรแกรมโดยคลิกไปที่ DobotStudioSetup
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612238686349_1612238147208.jpg)

2. จากนั้นให้ทำการเลือกภาษาของโปรแกรมที่ต้องการใช้ เมื่อเสร็จแล้วกด Next
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612238833371_1612238170290.jpg)

3. ก่อนการติดตั้งจะให้ยอมรับ license กด accept แล้วกด Next
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612238913110_1612238192359.jpg)
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612238913120_1612238209719.jpg)


4. เลือก path ที่เราจะติดตั้ง แล้วกด next

![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612239165871_1612238312110.jpg)

5. 
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612239193805_1612238261661.jpg)

6. กด install 
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319278828_1612238341319.jpg)

7. รอจนกว่าจะติดตั้งเสร็จ
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319120007_18.PNG)

8. หลังจากนั้นกด next และหย้าต่างถัดไปก็กดยอมรับและกด
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319483828_1612238406382.jpg)
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319483851_1612238418477.jpg)
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319483867_1612238433527.jpg)

9. กด next แล้วกดตาม step รูปด้านล่าง
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319533669_1612238450661.jpg)

![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319533589_1612238471269.jpg)
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319533642_1612238482078.jpg)
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319533656_1612238497264.jpg)

10. โปรแกรม DobotStudio ติดตั้งเสร็จเรียบร้อย
![](https://paper-attachments.dropbox.com/s_4AB53EF1EFE193534221B0A688EAC867082BD04A77EE84E2AAFFC042A2AEDCFC_1612319242545_31.PNG)



----------
## การใช้งานโปรแกรม Dobot Studio เบื้องต้น

Function Modules: 
คุณสามารถใช้ Dobot Studio เพื่อควบคุม Dobot Magician เพื่อทำหน้าที่ต่างๆ เช่นการสอน การเล่น การเขียน การวาดและเขียน การเขียนโปรแกรมบล็อคกราฟิก และการควบคุมสคริปต์ ดังแสดงตามรูปด้านล่าง  

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616578054669_image.png)

| Function Modules    | Description                                                                                                                                                 |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Teaching & Playback | สอนวิธีการเคลื่อนไหวและบันทึกการเคลื่อนไหวที่ Dobot Magician                                                                                                |
| Write & Draw        | ควบคุมแขนหุ่นยนต์เพื่อเขียนวาดหรือแกะสลักวัตถุโดยใช้เลเซอร์                                                                                                 |
| Blockly             | ใช้ Blockly เพื่อตั้งโปรแกรมแขนหุ่นยนต์ในการเขียนโปรแกรมกราฟิก ช่วยให้ผู้ใช้สามารถลากและวางบล็อกลงในที่ทำงานได้ ซึ่งทำให้ใช้งานง่ายและง่ายเหมือนตัวต่อบล็อก |
| Script              | ควบคุมแขนหุ่นยนต์โดยใช้คำสั่งสคริปต์                                                                                                                        |
| Leap Motion         | รองรับการเคลื่อนไหวของมือเป็นอินพุตเพื่อควบคุมแขนหุ่นยนต์ผ่านตัวควบคุม Leap Motion                                                                          |
| Mouse               | ควบคุมแขนหุ่นยนต์โดยใช้เมาส์                                                                                                                                |
| LaserEngraving      | การแกะสลักด้วยเลเซอร์                                                                                                                                       |
| 3DPrinter           | สามารถพิมพ์ 3 มิติได้                                                                                                                                       |

## คำอธิบายเครื่องมือในโปรแกรม DobotStudio: 


![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616578965581_image.png)


คุณสามารถเลือก Linear rail หรือ end-effector โดยคำอธิบายอยู่ในตารางด้านล่าง

| Items                          | Description                                                                                                        |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| Linear rail                    | เมื่อแขนหุ่นยนต์เชื่อมต่อกับ Linear rail เส้นให้คลิกรายการนี้เพื่อเปิดใช้งาน                                       |
| End-effector<br>drop-down list | เมื่อ end-effector เป็น cup kit, gripper kit, laser kit or writing and drawing kit ให้คลิกรายการนี้เพื่อเปิดใช้งาน |

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616578978674_image.png)


คุณสามารถตั้งค่า Home, Emergency Stop และการดูเวอร์ชันโดยคำอธิบายอยู่ในตารางด้านล่าง

| Items                                                                                                                                 | Description                                                                                                                                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Home                                                                                                                                  | ตั้งค่า Dobot Magician กลับไปที่ตำแหน่งบ้านเพื่อรับตำแหน่งอ้างอิงที่ถูกต้อง<br>หรือในกรณีเมื่อ Dobot Magician กำลังเคลื่อนที่หากการเคลื่อนไหวของมันถูกขัดขวางโดยสิ่งกีดขวางให้คลิก home เพื่อทำกลับจุดเริ่มต้น |
| Emergency Stop                                                                                                                        | หยุดแขนหุ่นยนต์หากเกิดเหตุฉุกเฉิน                                                                                                                                                                              |
| ![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616579468008_image.png) | ดูข้อมูลเวอร์ชัน เช่น เวอร์ชัน DobotStudio เวอร์ชันเฟิร์มแวร์และ<br>เวอร์ชันฮาร์ดแวร์                                                                                                                          |
| ![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616579442886_image.png) | เปลี่ยนภาษา                                                                                                                                                                                                    |



และคุณสามารถสอนให้แขนหุ่นยนต์ทำงานได้โดยเครื่องมือตามรูปด้านล่าง

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616579773604_image.png)



| Items                 | Description                                                                                                               |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Coordinate jogging    | ขยับเบาๆที่ Dobot Magician โดยคลิก X (X +/-), Y (Y +/-), Z (Z +/-) หรือ R (R +/-) ใน<br>ระบบพิกัดคาร์ทีเซียน              |
| Joint jogging         | ขยับเบาๆที่ Dobot Magician โดยคลิก Dobot Magician โดยคลิก J1 +/-, J2 +/-, J3 +/- หรือ J4 +/- ในระบบพิกัดร่วม              |
| Linear control        | เมื่อเปิดใช้งาน linear rail ให้คลิก L +/- เพื่อเคลื่อนแขนหุ่นยนต์ไปตามราง<br>ช่วงค่า: 0 mm - 1000 mm                      |
| Gripper control       | เมื่อเลือก end-effector เป็น Gripper คุณสามารถตั้งค่าให้ Gripper เปิด/ปิด หรือ<br>ปิดการใช้งาน Gripper เลื่อนขึ้นเลื่อนลง |
| Suction cup control   | เมื่อเลือก end-effector เป็น Suction Cup ให้เลือก SuctionCup เพื่อเปิดปั๊มลม หากไม่ได้เลือกปั๊มลมจะปิดอยู่                |
| Laser control         | เมื่อเลือก end-effector เป็น Laser ให้เลือก Laser เพื่อเปิดเลเซอร์ หากไม่ได้เลือกแสดงว่าเลเซอร์จะปิด                      |
| Jogging speed control | กำหนดเปอร์เซนต์ความเร็วในกาารขยับ<br><br>- ค่าเริ่มต้น: 50%<br>- ช่วงค่า: 1% - 100%                                       |



----------
## ตัวอย่างการใช้งาน Dobot Studio กับหุ่นยนต์ Dobot Magician
## LAB 1 ทดลองใช้ playback

ใช้ mode playback โดยจะใช้มือขยับแขน robot แล้ว save ค่า parameter ต่างๆ ของ robot เป็น node ได้

ใช้ program สั่งให้ขยับ แขน robot ได้ตามตำแหน่งที่ save ไว้ โดยปรับจำนวน loop และ speed ได้

![](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616571762402_image.png)

https://www.dropbox.com/s/xclaamdlfsah009/30672.t.mp4?dl=0



## Lab 2 อธิบาย joint ของ  robot ด้วย Operation panel


![ข้อมูล joint](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616579639785_image.png)


joint 1   base ของ robot หมุน ซ้าย-ขวา
joint 2  rear arm หมุน เข้า-ออก จากฐาน robot
joint 3  forearm   หมุน เข้า-ออก จากฐาน robot
joint 4 ต้องต่อเพิ่ม

จะปรับค่า joint เดียวให้เปลี่ยนไปเยอะที่สุด เพื่อดูการเคลื่อนไหวของ robot

![จุด home](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616576141825_image.png)
![จุดเริ่มต้น](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616577947432_30674.jpg)



![ปรับค่า J1](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616576957379_image.png)
![หมุนซ้าย-ขวา](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616577947441_30675.jpg)



![ปรับค่า J2](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616577088386_image.png)
![งอแขนใน เข้า-ออก](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616577947446_30676.jpg)



![ปรับค่า J3](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616577253762_image.png)
![งอแขนนอก เข้า-ออก](https://paper-attachments.dropbox.com/s_9B26D4212F2BBFEB10A70E92ABD55496EA55A4A079E6B8E94961F9E50ACFA50F_1616577947449_30677.jpg)



## Lab 3  ควบคุมแขน robot ด้วย mouse
![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616919307474_image.png)


แขน robot จะขยับตามแกนใน mouse โดย ค่า z จะเป็น 0

https://www.dropbox.com/s/mvxl2pz9jjy4pas/30681.t.mp4?dl=0

----------
# ตัวอย่างการใช้งาน Dobot Magician ร่วมกับตัวอุปกรณ์ใน DobotStudio

case#1 ใช้ Dobot Magician วาดและเขียน 

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616919232542_image.png)


ตัว simulator ที่ต้องการส่งให้ dobot ทำงาน 

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616919029195_image.png)


ผลที่ได้ 

https://www.dropbox.com/s/bfho77z96o0lo5n/638445485.505642.mp4?dl=0

----------

case#2 การใช้ vacum ในการเคลื่อนย้ายสิ่งของ 

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616919245945_image.png)


ตัว simulator ที่ต้องการส่งให้ dobot ทำงาน 

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616918992894_image.png)


ผลที่ได้

https://www.dropbox.com/s/6zz25tpuyo6h9uf/638611433.891629.mp4?dl=0

----------

case#3 การใช้ตัว gripper ในการเคลื่อนย้ายสิ่งของ 

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616922919138_image.png)


ตัว simulator ที่ต้องการส่งให้ dobot ทำงาน 

![](https://paper-attachments.dropbox.com/s_A1B5C38B44C14CEB458C3BEE6052EC63D5910BBA88ED97EDDB6C1C634D0B9732_1616922884700_image.png)


ผลที่ได้ 

https://www.dropbox.com/s/fc5u84hr0s52wyy/gripper.mp4?dl=0


