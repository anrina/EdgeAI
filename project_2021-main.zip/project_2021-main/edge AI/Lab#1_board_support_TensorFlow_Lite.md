# Lab#1_board_support_TensorFlow_Lite
TensorFlow Lite สำหรับไมโครคอนโทรลเลอร์ได้รับการออกแบบเพื่อเรียกใช้โมเดลการเรียนรู้ของเครื่อง บนไมโครคอนโทรลเลอร์และอุปกรณ์อื่นๆ และสามารถรันโมเดลพื้นฐานได้หลายแบบ ซึ่ง TensorFLow Lite ได้รับการทดสอบอย่างกว้างขวางกับโปรเซสเซอร์หลายตัวที่ใช้สถาปัตยกรรม Arm Cortex-M Series และรวมถึง ESP32 เฟรมเวิร์กมีให้ใช้งานเป็นไลบรารี Arduino นอกจากนี้ยังสามารถสร้างโครงการสำหรับ enviroment สำหรับการพัฒนาเช่น Mbed ที่เป็นโอเพ่นซอร์ส

บอร์ดที่รองรับ TensorFlow Lite:

- STM32F746 Discovery kit
- Adafruit PyBadge
- Espressif ESP-EYE
- OpenMV Cam M7
- Sipeed MAix
- Google Coral Dev Board
- Jetson Nano
- Raspberry Pi Pico




----------
# STM32F746 Discovery kit
![](https://paper-attachments.dropbox.com/s_0CA267EF55D65B125A6EA99F5C02B686968CED9CA886F881B02B82785F0DB6B8_1616478540965_Capture.PNG)
![](https://paper-attachments.dropbox.com/s_0CA267EF55D65B125A6EA99F5C02B686968CED9CA886F881B02B82785F0DB6B8_1616478540989_.PNG)


STM32F746 Discovery kit สามารถใช้งานได้หลากหลายแอพพลิเคชั่น โดยมีประโยชน์ในด้านเสียง, ด้านการรองรับเซนเซอร์หลายตัว, ด้านกราฟฟิก, ด้านความปลอดภัย, ด้านวิดิโอ หรือจะเป็นการเชื่อมต่อที่ความเร็วสูง และสามารถเชื่อมต่อกับบอร์ดเสริมได้มากมาย โดย STM32F746 Discovery kit มาพร้อมกับ package MCU STM32CubeF7 ซึ่งนำเสนอไลบราลี HAL ของซอฟแวร์ STM32 ที่ครอบคลุม

**All features**

- STM32F746NGH6 Arm® Cortex® core-based microcontroller with 1 Mbyte of Flash memory and 340 Kbytes of RAM, in BGA216 package
- 4.3” RGB 480×272 color LCD-TFT with capacitive touch screen
- Ethernet compliant with IEEE-802.3-2002
- USB OTG HS
- USB OTG FS
- SAI audio codec
- Two ST-MEMS digital microphones
- 128-Mbit Quad-SPI Flash memory
- 128-Mbit SDRAM (64 Mbits accessible)
- Two user and reset push-buttons
- Board connectors:
    - Camera
    - microSD™ card
    - RF-EEPROM daughterboard connector
    - 2×USB with Micro-AB
    - Ethernet RJ45
    - SPDIF RCA input connector
    - Audio line in and line out jack
    - Stereo speaker outputs
    - ARDUINO Uno V3 expansion connectors
- Flexible power-supply options: ST-LINK, USB VBUS or external sources
- Power supply output for external applications: 3.3 V or 5 V
- Comprehensive free software libraries and examples available with the STM32Cube MCU Package
- On-board ST-LINK/V2-1 debugger/programmer with USB re-enumeration capability: mass storage, Virtual COM port, and debug port
- Support of a wide choice of Integrated Development Environments (IDEs) including IAR™, Keil®, GCC-based IDEs, and Arm® Mbed™


![](https://paper-attachments.dropbox.com/s_0CA267EF55D65B125A6EA99F5C02B686968CED9CA886F881B02B82785F0DB6B8_1616478462977_QKsf1ivA.png)
![](https://paper-attachments.dropbox.com/s_0CA267EF55D65B125A6EA99F5C02B686968CED9CA886F881B02B82785F0DB6B8_1616478463013_SSQWtU8w.png)



# Adafruit PyBadge
![](https://lh3.googleusercontent.com/oXrYOda0CmQxUXDEP4FzQELhPTLHVb7-SCpStBd4pPudSOSi3czSdhVl5OmkCxz5q6tRXa4gvT34tPKrVTFH_PoNpOEuInyPJShs3zzCN69laDP5SQ_Xg7V95YOk10fZUpSzlQLK)


 
Adafruit PyBadge เป็นไมโครคอนโทรลเลอร์ขนาดเล็กที่สามารถเรียกใช้ TensorFlow Lite เพื่อทำการคำนวณ Machine Learning (ML) ได้และไมโครคอนโทรลเลอร์ตัวนี้ ไม่จำเป็นต้องใช้ฮาร์ดแวร์ที่ซับซ้อนมาก เพราะในตัวนี้ประกอบด้วย 

- ATSAMD51J19 @ 120MHz with 3.3V logic/power - 512KB of FLASH + 192KB of RAM
- 2 MB of SPI Flash for storing images, sounds, animations, whatever!
- 1.8" 160x128 Color TFT Display connected to its own SPI port
- 8 x Game/Control Buttons with nice silicone button tops (these feel great)
- 5 x NeoPixels for badge dazzle, or game score-keeping
- Triple-axis accelerometer (motion sensor)
- Light sensor, reverse-mount so that it points out the front
- Built in buzzer mini-speaker
- Mono Class-D speaker driver for 4-8 ohm speakers, up to 2 Watts
- LiPoly battery port with built in recharging capability
- USB port for battery charging, programming and debugging
- Two female header strips with Feather-compatible pinout so you can plug any FeatherWings in
- JST ports for NeoPixels, sensor input, and I2C (you can fit I2C Grove connectors in here)
- Reset button
- On-Off switch


# Espressif ESP-EYE
![](https://lh3.googleusercontent.com/S8o9_zzixV6XOicu0Ck002kDQFaROA8m2iUpi3LwFtOgbUS_2RY26uE8Om8FuOQa-hObk_ZmkWME_HwBVGrN9Ov_cD9RY9UPSfGUcnrt8pNDRhEVzevP4Whv9bQwjyxMkJDBuBbR)



ESP-EYE เป็นบอร์ดพัฒนาสำหรับการจดจำภาพและการประมวลผลเสียงซึ่งสามารถใช้ในแอพพลิเคชั่น AIoT ต่างๆ มีชิป ESP32, กล้อง 2 ล้านพิกเซลและไมโครโฟน ESP-EYE มีพื้นที่เก็บข้อมูลมากมายพร้อมด้วย PSRAM 8 Mbyte และแฟลช 4 Mbyte นอกจากนี้ยังรองรับการส่งภาพผ่าน Wi-Fi และการดีบักผ่านพอร์ต Micro-USB
โดยมีซอฟแวร์ ด้าน IOT คือ ESP-IDF และมี มีซอฟแวร์ ด้าน AI คือ ESP-WHO

- ESP-IDF คือ Espressif IoT Development Framework (esp-idf) ESP-IDF เป็น Framework ที่พัฒนาสำหรับชิป ESP32 
- ESP-WHO เป็น Framework ที่ตรวจจับและจดจำใบหน้าที่ออกแบบมาสำหรับแอปพลิเคชัน AIoT ที่ใช้ชิป ESP32 ของ Espressif Systems ซึ่งสามารถใช้กับบอร์ดพัฒนา ESP-EYE หรือบอร์ดพัฒนาที่ใช้ ESP32 อื่น ๆ จากนั้นเพิ่มอุปกรณ์ต่อพ่วงเพียงไม่กี่ชิ้นเช่นกล้องและหน้าจอ

**Features:**

- Evaluates image recognition and audio processing used in various AIoT applications
- Features an ESP32 chip, a 2-Megapixel camera and a microphone
- 8Mbyte PSRAM and a 4Mbyte flash storage
- Supports image transmission via Wi-Fi®
- Supports debugging through a Micro-USB port

**Features:**

- A 3D PIFA antenna. With the R14 resistor users can select the external IPEX antenna, whereas with the R15 resistor they can select the 3D antenna.
- IPEX Connector used for connecting the external IPEX antenna. With the R14 resistor users can select the external IPEX antenna, whereas with the R15 resistor they can select the 3D antenna.
- WiSoC ESP32 dual core Tensilica LX6 processor with WiFi and Bluetooth
- Crystal Oscillator provides an external clock to ESP32.
- 4MB Flash & 8MB PSRAM provides memory for storing applications.
- CP2102 USB-to-UART Chip converts the USB signals to UART signals.
- USB Port provides power supply to the whole system.
- LDO power supply provides the required power supply to the ESP32 chip, camera and LED indicators.
- LED Indicators. The board has a red and a white indicator. Different flashing combinations of the red and white indicators reflect the different statuses of the board, e.g. waking up, networking, face detection, face recognition, face enrollment and face recognition.
- An external 2-Megapixel OV2640 camera module for face detection, face recognition and Face ID enrollment.
- A digital MEMS microphone for voice control functions.
- SPI Port. A reserved port for data transmission.


![](https://lh5.googleusercontent.com/5I0AQhysNF1dDR4tt88FKB4qfRHXlhtTRST1jOxI3wmJQl46Ms4I8EDTlWjNY6rTxWXld1hilwGE3_tuF2X64pfnFC1zC85PVowmbyFpEfysEI5abxwXEzLB8V8YFLjCbrz8JqS8)



# OpenMV Cam M7
![](https://cdn.shopify.com/s/files/1/0803/9211/products/web-1_grande.jpg?v=1480874705)


OpenMV Cam M7 เป็นบอร์ดไมโครคอนโทรลเลอร์ขนาดเล็กที่ใช้พลังงานต่ำ มาพร้อมกับเซ็นเซอร์ภาพ OV7725 ที่สามารถถ่ายภาพแบบ Grayscale 8-bit ขนาด 640x480 หรือ ภาพแบบ RGB565 16-bit ที่ 75 FPS เมื่อความละเอียดสูงกว่า 320x240 และที่ 150 FPS เมื่อความละเอียดต่ำกว่า 320x240

นอกจากนี้ยังมีโมดูลกล้องแบบถอดได้ซึ่งช่วยให้สามารถใช้โมดูลกับ Global Shutter และเซ็นเซอร์ FLIR Lepton สำหรับการใช้งานด้านการมองเห็นคอมพิวเตอร์ที่จริงจัง

OpenMV เหมาะสำหรับแอปพลิเคชันที่เกี่ยวข้องกับการตรวจจับใบหน้า การติดตามดวงตาและเครื่องหมายการตรวจจับ หรือจะเป็นการถอดรหัส QR การตรวจจับรูปร่างและอื่น ๆ


## Interface Library

OpenMV Cam มาพร้อมกับไลบรารี RPC (Remote Python / Procedure Call) ในตัวซึ่งทำให้ง่ายต่อการเชื่อมต่อ OpenMV Cam กับคอมพิวเตอร์ SBC (คอมพิวเตอร์บอร์ดเดียว) เช่น RaspberryPi หรือ Beaglebone หรือไมโครคอนโทรลเลอร์เช่น Arduino หรือ ESP8266 / 32 ไลบรารีอินเตอร์เฟส RPC

Async Serial (UART) - ที่ความเร็ว 7.5 Mb /s
I2C Bus - สูงสุด 1 Mb/s
SPI Bus - สูงสุด 54 Mb/s
CAN Bus - สูงสุด 1 Mb/s
พอร์ต USB Virtual COM (VCP) - สูงสุด 12 Mb/s
WiFi โดยใช้ WiFi Shield - สูงสุด 12 Mb/s


## The OpenMV Cam features:
- The STM32F765VI ARM Cortex M7 processor running at 216 MHz with 512KB of RAM and 2 MB of flash. All I/O pins output 3.3V and are 5V tolerant. The processor has the following I/O interfaces:
    - A full speed USB (12Mbs) interface to your computer. Your OpenMV Cam will appear as a Virtual COM Port and a USB Flash Drive when plugged in.
    - A μSD Card socket capable of 100Mbs reads/writes which allows your OpenMV Cam to record video and easy pull machine vision assets off of the μSD card.
    - A SPI bus that can run up to 54Mbs allowing you to easily stream image data off the system to either the LCD Shield, the WiFi Shield, or another microcontroller.
    - An I2C Bus (up to 1Mb/s), CAN Bus (up to 1Mb/s), and an Asynchronous Serial Bus (TX/RX, up to 7.5Mb/s) for interfacing with other microcontrollers and sensors.
    - A 12-bit ADC and a 12-bit DAC.
    - Three I/O pins for servo control.
    - Interrupts and PWM on all I/O pins (there are 10 I/O pins on the board).
    - And, an RGB LED and two high power 850nm IR LEDs.
- The OV7725 image sensor is capable of taking 640x480 8-bit Grayscale images or 640x480 16-bit RGB565 images at 75 FPS when the resolution is above 320x240 and 150 FPS when it is below. Most simple algorithms will run between 75-150 FPS on QVGA (320x240) resolutions and below.  Your OpenMV Cam comes with a 2.8mm lens on a standard M12 lens mount. If you want to use more specialized lenses with your OpenMV Cam you can easily buy and attach them yourself.


# Sipeed MAix
![](https://miro.medium.com/max/1144/1*5EyqbbOc_dTg9jxfLfKasw.png)


MAIX เป็นโมดูลที่สร้างขึ้นตามวัตถุประสงค์ของ Sipeed ซึ่งออกแบบมาเพื่อเรียกใช้ AI ที่เรียกว่า AIoT
โดย MAIX มีขนาดเล็กแต่มอบประสิทธิภาพการทำงานที่สูงและการใช้พลังงานทำให้สามารถใช้ AI ที่มีความแม่นยำสูง 


## ข้อดีและการใช้งานของ MAix 

MAIX ไม่ได้เป็นเพียงฮาร์ดแวร์เท่านั้น แต่ยังมีโครงสร้างพื้นฐานฮาร์ดแวร์ + ซอฟต์แวร์แบบ end-to-end เพื่ออำนวยความสะดวกในการปรับใช้โซลูชันที่ใช้ AI
ด้วยประสิทธิภาพการทำงานขนาดเล็กใช้พลังงานต่ำและต้นทุนต่ำ MAIX ช่วยให้สามารถปรับใช้ AI คุณภาพสูงได้ในวงกว้าง
MAIX สามารถใช้กับกรณีการใช้งานในอุตสาหกรรมที่มีจำนวนเพิ่มมากขึ้น เช่น การคาดการณ์ในบำรุงรักษา, การตรวจจับความผิดปกติ, การมองเห็นของเครื่องจักร, หุ่นยนต์, การจดจำเสียงและอื่นๆอีกมากมาย


## CPU ของ MAix

ในฮาร์ดแวร์ MAIX มี KPU K210 ที่ทรงพลังอยู่ภายในมีคุณสมบัติที่น่าตื่นเต้นมากมาย:

- 1st competitive RISC-V chip, also 1st competitive AI chip, newly release in Sep. 2018
- 28nm process, dual-core RISC-V 64bit IMAFDC, on-chip huge 8MB high-speed SRAM (not for XMR :D), 400MHz frequency (able to 800MHz)
- KPU (Neural Network Processor) inside, 64 KPU which is 576bit width, support convolution kernels, any form of activation function. It offers 0.25TOPS@0.3W,400MHz, when overclock to 800MHz, it offers 0.5TOPS. It means you can do object recognition 60fps@VGA
- APU (Audio Processor) inside, support 8mics, up to 192KHz sample rate, hardcore FFT unit inside, easy to make a Mic Array (MAIX offer it too)
- Flexible FPIOA (Field Programmable IO Array), you can map 255 functions to all 48 GPIOs on the chip
- DVP camera and MCU LCD interface, you can connect an DVP camera, run your algorithm, and display on LCD
- Many other accelerators and peripherals: AES Accelerator, SHA256 Accelerator, FFT Accelerator (not APU's one), OTP, UART, WDT, IIC, SPI, I2S, TIMER, RTC, PWM, etc.


## โมดูลของ MAix

โมดูล Sipeed MAIX-I หรือที่เรียกว่า M1 รวมถึง K210 มี 3-channel DC-DC power, 8MB/16MB/128MB Flash (โมดูล M1w เพิ่มชิป wifi esp8285)
IO ที่ใช้งานได้ทั้งหมดแตกออกเป็นพิน 1.27mm(50mil) และสามารถเลือกแรงดันไฟฟ้าของพินได้ตั้งแต่ 3.3V และ 1.8V

![](https://paper-attachments.dropbox.com/s_0CA267EF55D65B125A6EA99F5C02B686968CED9CA886F881B02B82785F0DB6B8_1616486652235_Sipeed-M1-aa.jpg)



# Google Coral Dev Board

https://coral.ai/docs/dev-board/datasheet/#overview

![](https://www.blognone.com/sites/default/files/externals/ce82dfdb40f4593de84a4504af287abb.jpg)


Dev Board เป็นคอมพิวเตอร์บอร์ดที่เหมาะสำหรับการทำ Machine Learning (ML) ในรูปแบบขนาดเล็ก ซึ่งสามารถใช้ Dev Board เพื่อสร้างต้นแบบ embedded system 

โดยแกนกลางของ Coral คือ **Edge TPU** ชิป ASIC ที่กูเกิลออกแบบเองให้ประมวลผล neural networks (NNs) อย่างมีประสิทธิภาพ โดยที่ยังกินไฟต่ำ และสามารถนำไปใช้งานกับอุปกรณ์ปลายทาง (edge) ที่มักเป็นอุปกรณ์ฝังตัวได้

โดย **Coral Dev Board** บอร์ดที่แปะ Edge TPU ใช้พัฒนาฮาร์ดแวร์ต้นแบบ รัน TensorFlow Lite ตัวหน่วยประมวลผลสามารถถอดออกจากตัวบอร์ดได้ (system-on-module - SOM)
และมีโมดูลเพิ่มประสิทธิภาพในการใช้งานได้แก่ 

- **Camera Module** โมดูลกล้องพร้อมเซ็นเซอร์ความละเอียด 5MP ใช้ร่วมกับ Dev Board
- **USB Accelerator** เป็นการนำ Edge TPU มาใส่ในรูป thumbdrive เสียบเข้ากับพีซีผ่าน USB-C เพื่อช่วยเร่งการประมวลผล ML ให้กับพีซี (เหมือนเป็นหน่วยประมวลผล ML แยกเฉพาะที่เสียบ USB-C) ความเร็วเป็น USB 3.1 (5Gbps) และมี Cortex-M0+ สำหรับการสั่งการพื้นฐานมาให้ด้วย
- **PCI-E Accelerator** แนวคิดแบบเดียวกัน แต่เปลี่ยนรูปทรงเป็นการ์ดเสียบลงพอร์ต PCI-E แทน

Coral Dev Board ประกอบด้วยชิป NXP i.MX 8M ภายในเป็น Cortex-A53 จำนวน 4 คอร์ และ microcontroller Cortex-M4F RAM 1GB ความจุ eMMC 8GB รองรับ Wi-Fi 2x2 MIMO (802.11b/g/n/ac 2.4/5GHz) and Bluetooth 4.2 ด้วย มี Gigabit Ethernet port, USB-C, USB-A 3.0, และ micro USB สำหรับคอนโซล ต่อจอภาพใช้ port HDMI 2.0a, MIPI-DSI 24 พิน, และต่อกล้องด้วย MIPI-CSI2 และชิป Edge TPU 



| **CPU**            | NXP i.MX 8M SoC (quad Cortex-A53, Cortex-M4F)                                                                                 |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------- |
| **GPU**            | Integrated GC7000 Lite Graphics                                                                                               |
| **ML accelerator** | Google Edge TPU coprocessor:<br>4 TOPS (int8); 2 TOPS per watt                                                                |
| **RAM**            | 1 GB LPDDR4 (option for 2 GB or 4 GB coming soon)                                                                             |
| **Flash memory**   | 8 GB eMMC, MicroSD slot                                                                                                       |
| **Wireless**       | Wi-Fi 2x2 MIMO (802.11b/g/n/ac 2.4/5GHz) and Bluetooth 4.2                                                                    |
| **USB**            | Type-C OTG; Type-C power; Type-A 3.0 host; Micro-B serial console                                                             |
| **LAN**            | Gigabit Ethernet port                                                                                                         |
| **Audio**          | 3.5mm audio jack (CTIA compliant); Digital PDM microphone (x2); 2.54mm 4-pin terminal for stereo speakers                     |
| **Video**          | HDMI 2.0a (full size); 39-pin FFC connector for MIPI-DSI display (4-lane); 24-pin FFC connector for MIPI-CSI2 camera (4-lane) |
| **GPIO**           | 3.3V power rail; 40 - 255 ohms programmable impedance; ~82 mA max current                                                     |
| **Power**          | 5V DC (USB Type-C)                                                                                                            |
| **Dimensions**     | 88 mm x 60 mm x 24mm                                                                                                          |



## Features
- Edge TPU System-on-Module (SoM)
    - NXP i.MX 8M SoC (Quad-core Arm Cortex-A53, plus Cortex-M4F)
    - Google Edge TPU ML accelerator coprocessor
    - Cryptographic coprocessor
    - Wi-Fi 2x2 MIMO (802.11b/g/n/ac 2.4/5 GHz)
    - Bluetooth 4.2
    - 8 GB eMMC
    - 1 or 4 GB LPDDR4
- USB connections
    - USB Type-C power port (5 V DC)
    - USB 3.0 Type-C OTG port
    - USB 3.0 Type-A host port
    - USB 2.0 Micro-B serial console port
- Audio connections
    - 3.5 mm audio jack (CTIA compliant)
    - Digital PDM microphone (x2)
    - 2.54 mm 4-pin terminal for stereo speakers
- Video connections
    - HDMI 2.0a (full size)
    - 39-pin FFC connector for MIPI DSI display (4-lane)
    - 24-pin FFC connector for MIPI CSI-2 camera (4-lane)
- MicroSD card slot
- Gigabit Ethernet port
- 40-pin GPIO expansion header
- Supports Mendel Linux (derivative of Debian)



## Baseboard connections
![](https://coral.ai/static/docs/images/devboard/devboard-port-callouts-illi-named.png)

## I/O header pinout

มีพิน I/O ทั้งหมด 40 พิน โดยใช้พลังงานจากรางไฟที่ 3.3V โดยมี impedance ที่ตั้งโปรแกรมได้ 40-255 ohm และกระแสไฟสูงสุดที่ ~82 mA (อย่าเชื่อมต่ออุปกรณ์ที่ใช้พลังงานมากกว่า ~82 mA ไม่เช่นนั้นระบบจะปิดหรือเสียหายได้)



## feature ของ coral:
- การตรวจจับวัตถุ - วาดสี่เหลี่ยมรอบๆ ตำแหน่งของวัตถุต่างๆที่เป็นที่รู้จักในภาพ
- การประมาณท่าทาง - ประเมินท่าทางของผู้คนในภาพโดยระบุข้อต่อต่างๆของร่างกาย 
- การแบ่งส่วนภาพ - ระบุวัตถุต่างๆในภาพและตำแหน่งของวัตถุแบบพิกเซลต่อพิกเซล 
- การตรวจจับคำพูด - ฟังตัวอย่างเสียงและจดจำคำและวลีที่รู้จักได้อย่างรวดเร็ว




# Jetson Nano
![Jetson Nano](https://eleceasy.com/uploads/default/original/2X/0/00698339347abf3c8c5df2f4de559c60259eebf6.png)


Jetson Nano บอร์ด AI แรม 4GB พลังประมวลผล 472GFLOPS ซึ่งโมดูลประมวลผล ด้วยซีพียูเป็น Cortex-A57 ทำงานที่สัญญาณนาฬิกา 1.43 GHz มาพร้อมกับแรม LPDDR4 4GB และคอร์ Maxwell 128 คอร์ ด้าน I/O สามารถต่อ USB 3.0 มี 4 ช่อง, micro USB 1 ช่อง, HDMI 2.0 และมีพอร์ต eDP 1.4 ด้วย

| Feature     | Description                                                    |
| ----------- | -------------------------------------------------------------- |
| **GPU**     | 128 Core Maxwell 0.5 TFLOPs (FP16)                             |
| **CPU**     | 4 core ARM A57 @ 1.43 GHz                                      |
| **Memory**  | 4 GB 64 bit LPDDR4 25.6 GB/s                                   |
| **Storage** | 16 GB eMMC                                                     |
| **Encoder** | H.264/H.265 up to 4K@30, 4 x 1080p@30, 9 x 720p@30             |
| **Decoder** | H.264/H.265 up to 4K@60, 2 x 4K@20, 8 x 1080p@30, 18 x 720p@30 |

**Peripherals**

- 1 x1/2/4 PCIE
- 1 USB 3.0
- SD/MMC Controller
- Display
    - HDMI 2.0 or DP1.2
    - Up to 2 simultaneous displays
- Camera
    - 12 (3x4 or 4x2) MIPI CSI-2 DPHY 1.1 lanes (1.5 Gbps)
    - Compatible with Raspberry-Pi v2 camera module
- WiFi/BT — equires external chip
- 1 x SDIO
- 2 x SPI
- 5 x SysIO
- 3 x GPIOs
- 6 x I2C

feature ของ coral:

- การเรียนรู้ AI แบบ interface - เรียนรู้ AI ด้วยการสร้างแอปพลิเคชั่นสนุกๆ ติดตั้งและใช้งานง่ายเข้ากันได้กับอุปกรณ์เสริมมากมายและมีบทช่วยสอนแบบ interactive ที่แสดงวิธีควยคุมพลังของ AI ในการติดตามวัตถุหลีกเหลี่ยงการชนและอื่นๆ
- Hello AI World - เริ่มใช้ Jetson และสัมผัสกับพลังของ AI  พร้อมชุดตัวอย่างการอนุมานเชิงลึก สำหรับการจำแนกภาพแบบเรียลไทม์ และการตรวจจับวัตถุโดยใช้โมเดลที่กำหนดไว้ล่วงหน้าใน Jetson Developer Kit ด้วย JetPack SDK
- JetRacer - รถแข่ง AI อัตโนมัติโดยใช้ NVIDIA Jetson Nano ด้วย JetRacer ความสามารถ เช่น
    - Go-Fast - เพิ่มประสิทธิภาพสำหรับ Framerate สูงเพื่อเคลื่อนที่ด้วยความเร็วสูง
    - Have-Fun - ทำตามตัวอย่างและโปรแกรมแบบโต้ตอบบจากตัวเบราว์เซอร์
- ประมาณท่าทางแบบเรียลไทม์ - มีการประมาณท่าทางแบบหลายอินสแตนซ์ที่เร่งโดย NVIDIA TensorRT เหมาะอย่างยิ่งสำหรับการใช้งานที่จำเป็นต้องมีเวลาจำกัด


# **Raspberry Pi Pico**
![Raspberry Pi Pico](https://static.cytron.io/image/cache/catalog/products/RPI-PICO-B/RPI-PICO-B_h-800x800.jpg)


Raspberry Pi Pico ถูกออกแบบมาสำหรับการคำนวณหรือการควบคุมทางกายภาพซึ่งเป็นการควบคุมอุปกรณ์อิเล็กทรอนิกส์ชิ้นเล็กๆ ไม่ว่าจะเป็น LEDs, มอเตอร์, อ่านค่าจากเซนเซอร์ต่างๆ หรือสื่อสารกับไมโครคอนโทรเลอร์ตัวอื่นๆ
Raspberry Pi Pico เป็นบอร์ดไมโครคอนโทรเลอร์ที่สามารถทำการคำนวณ หรือควบคุมการทำงานต่างๆ โดยสามารถเขียนโปรแกรมเพื่อควบคุมตัวบอร์ดได้อย่างง่ายดายผ่านการเชื่อมต่อแบบ USB


## **Specification**
- 21 mm × 51 mm form factor
- RP2040 microcontroller chip designed by Raspberry Pi in the UK
- Dual-core Arm Cortex-M0+ processor, flexible clock running up to 133 MHz
- 264KB on-chip SRAM
- 2MB on-board QSPI Flash
- 26 multifunction GPIO pins, including 3 analogue inputs
- 2 × UART, 2 × SPI controllers, 2 × I2C controllers, 16 × PWM channels
- 1 × USB 1.1 controller and PHY, with host and device support
- 8 × Programmable I/O (PIO) state machines for custom peripheral support
- Supported input power 1.8–5.5V DC
- Operating temperature -20°C to +85°C
- Castellated module allows soldering direct to carrier boards
- Drag-and-drop programming using mass storage over USB
- Low-power sleep and dormant modes
- Accurate on-chip clock
- Temperature sensor
- Accelerated integer and floating-point libraries on-chip

โดย RP2040 ถูกออกแบบโดย Raspberry Pi RP2040 มีโปรเซสเซอร์ Arm Cortex-M0+ แบบ dual-core มี clock สูงสุด 133MHz พร้อม RAM แบบ static ขนาด 264KB และชิปแฟลชแบบ QSPI 2MB และรองรับแฟลชนอกชิปสูงสุด 16MB มีเซ็นเซอร์วัดอุณหภูมิ 12-bit ติดตั้งมาให้ในตัว พอร์ท micro USB-B, GPIO 26 ขา, UART 2 ขา, SPI 2 ขา I²C 2 ขา และ PWM pin อีก 16 ขา (ต่อพินแยกเอง) และ Raspberry Pi Pico นั้นรองรับไฟสูงสุด 1.8-5.5v

![](https://paper-attachments.dropbox.com/s_0CA267EF55D65B125A6EA99F5C02B686968CED9CA886F881B02B82785F0DB6B8_1616559927174_image.png)

## คุณสมบัติทางเทคนิค (เหมือนข้างบนแต่เป็นภาษาไทย)

๐ ติดตั้งชิปไมโครคอนโทรลเลอร์ RP2040 จาก Raspberry Pi สหราชอาณาจักร
๐ ส่วนของโปรเซสเซอร์เป็น Arm Cortex M0+ 2 แกน วงจรกำเนิดสัญญาณนาฬิกามีความยืดหยุ่นและทำงานได้ที่ความถี่สูงสุด 133MHz
๐ มีหน่วยความจำสแตติกแรม 264KB และหน่วยความจำแฟลชแบบ SPI ความจุ 2MB
๐ รองรับการทำงานเป็น USB1.1 โฮสต์ เพื่อเชื่อมต่อกับอุปกรณ์ USB ได้อย่างหลากหลาย
๐ มีการทำงานในโหมดประหยัดพลังงานในแบบสลีป (sleep) และดอร์แมนต์ (dormant)
๐ ดาวน์โหลดโค้ดแบบลากและวางไปยังดิสก์ไดรฟผ่านพอร์ต USB
๐ ขาพอร์ตอินพุตเอาต์พุตแบบมัลติฟังก์ชั่น 26 ขา รองรับการสร้างสัญญาณบัส I2S และสัญญาณเชื่อมต่อจอภาพแบบ VGA
๐ มีขาพอร์ตรองรับการสื่อสารข้อมูลอนุกรมผ่านบัส SPI 2 ชุด, I2C 2 ชุด และ UART 2 ชุด
๐ มีขาพอร์ตอินพุตแอนะล็อก 3 ขา สำหรับวงจรแปลงสัญญาณแอนะล็อกเป็นดิจิทัล ความละเอียด 12 บิต มีอัตราการสุ่มสัญญาณ 500 กิโลแซมปลิ้งต่อวินาที รองรับแรงดันไฟตรงสูงสุด 3.3V
๐ มีขาพอร์ตรองรับการทำงานสร้างสัญญาณ PWM แบบควบคุมได้ 16 ช่อง
๐ ไทเมอร์และฐานเวลาความเที่ยงตรงสูง
๐ มีตัวตรวจจับอุณหภูมิภายในชิป
๐ มีไลบรารีคำนวณคณิตศาสตร์เลขทศนิยมในตัวชิป
๐ พอร์ตอินพุตเอาต์พุตโปรแกรมได้ (PIO) เป็นสเตตแมชชีนแบบโปรแกรมได้ 8 ชุด ทำให้ปรับแต่งการทำงานของขาพอร์ตได้อย่างเป็นอิสระและหลากหลาย รองรับอุปกรณ์เพอริเฟอรัลในแบบเฉพาะได้
๐ มีขาพอร์ตรองรับการดีบักแบบ ARM Serial Wire Debug หรือ SWD 3 ขา
๐ ไฟเลี้ยงบอร์ดย่านกว้าง 1.8 ถึง 5.5V บนบอร์ดมีวงจรภาคจ่ายไฟควบคุมไฟเลี้ยงคงที่ 3.3V ในแบบเพิ่มและลดอัตโนมัติเมื่อ่ไฟเลี้ยงเข้ามาต่ำกว่า 1.8V และสูงกว่า 3.3V กระแสไฟฟ้าขณะทำงาน 87 ถึง 92mA ใช้แบตเตอรี่ AA หรือ AAA 3 ก้อนเป็นแหล่งจ่ายไฟได้
๐ การใช้กระแสไฟฟ้าในโหมดสลีป 1.3mA และ 0.8mA ในโหมดดอร์แมนต์


----------


## ตารางเทียบความแตกต่างของบอร์ดที่รองรับ TensorFlow Lite
| ชื่อบอร์ด               | CPU                                                                      | Flash memory                                | Quad-SPI Flash memory       | RAM                                                                                  | Storage                              | sensor                                                                                                       | I/O                                                                                                                                                                                                                    | Power supply output                                                                                 | Software Support                                                                                                             |
| ----------------------- | ------------------------------------------------------------------------ | ------------------------------------------- | --------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------ | ------------------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| STM32F746 Discovery kit | STM32F746NGH6 Arm® Cortex®                                               | 1 Mbyte                                     | 128-Mbit                    | 340 Kbytes                                                                           | 128-Mbit SDRAM (64 Mbits accessible) |                                                                                                              | - USB OTG HS<br>- USB OTG FS<br>- SAI audio codec<br>- USB with Micro-AB<br>- Ethernet RJ45                                                                                                                            | 3.3 V or 5 V                                                                                        | Support of a wide choice of Integrated Development Environments (IDEs) including IAR™, Keil®, GCC-based IDEs, and Arm® Mbed™ |
| Adafruit PyBadge        | ATSAMD51J19 @ 120MHz                                                     | 512KB                                       | 2 MB                        | 192KB                                                                                | 2 MB                                 | - Triple-axis accelerometer (motion sensor)<br>- Light sensor, reverse-mount so that it points out the front | - 8 x Game/Control Buttons<br>- 5 x NeoPixels for badge dazzle<br>- JST ports for NeoPixels, sensor input, and I2C                                                                                                     | 3.3V                                                                                                |                                                                                                                              |
| Espressif ESP-EYE       | ESP32 Chip @ 2.4 GHz                                                     | 4MB Flash                                   |                             | 8MB PSRAM                                                                            |                                      |                                                                                                              | - SPI Port                                                                                                                                                                                                             |                                                                                                     | - software ด้าน IoT คือ ESP-IDF<br>- software ด้าน AI คือ ESP-WHO                                                            |
| OpenMV Cam M7           | The STM32F765VI ARM Cortex M7 processor running at 216 MHz               | 2 MB of flash.                              |                             | 512KB of RAM                                                                         |                                      | OV7725 image sensor                                                                                          | - full speed USB (12Mbs)<br>- μSD Card socket capable of 100Mbs reads/writes<br>- SPI bus that can run up to 54Mbs<br>-  I2C Bus (up to 1Mb/s)<br>- Three I/O pins for servo control.                                  | 3.3V or 5V                                                                                          |                                                                                                                              |
| Sipeed MAix             | dual-core RISC-V 64bit IMAFDC                                            | 3-channel DC-DC power, 8MB/16MB/128MB Flash |                             | on-chip huge 8MB high-speed SRAM (not for XMR :D), 400MHz frequency (able to 800MHz) |                                      |                                                                                                              |                                                                                                                                                                                                                        | 3.3V or 1.8V                                                                                        |                                                                                                                              |
| Google Coral Dev Board  | NXP i.MX 8M SOC (quad Cortex-A53, Cortex-M4F)                            | 8GB of eMMC Flash memory                    |                             | 1 GB LPDDR4 RAM                                                                      | 8 GB eMMC                            |                                                                                                              | Type-C OTG; Type-C power; Type-A 3.0 host; Micro-B serial console                                                                                                                                                      | - 3.3V power rail; 40 - 255 ohms programmable impedance; ~82 mA max current<br>- 5V DC (USB Type-C) | - Supports Mendel Linux (derivative of Debian)                                                                               |
| Jetson Nano             | 4 core ARM A57 @ 1.43 GHz                                                |                                             |                             | 4 GB 64 bit LPDDR4 25.6 GB/s                                                         | 16 GB eMMC                           |                                                                                                              | - 1 x SDIO<br>- 2 x SPI<br>- 5 x SysIO<br>- 3 x GPIOs<br>- 6 x I2C                                                                                                                                                     |                                                                                                     |                                                                                                                              |
| Raspberry Pi Pico       | Dual-core Arm Cortex M0+ processor, flexible clock running up to 133 MHz | 2MB of on-board Flash memory                | รองรับแฟลชนอกชิปสูงสุด 16MB | 264KB of SRAM                                                                        |                                      |                                                                                                              | - 2 × UART, 2 × SPI controllers, 2 × I2C controllers, 16 × PWM channels<br>- 1 × USB 1.1 controller and PHY, with host and device support<br>- 8 × Programmable I/O (PIO) state machines for custom peripheral support | - Supported input power 1.8–5.5V DC                                                                 |                                                                                                                              |

 

 

